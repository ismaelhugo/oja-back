--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: deputados; Type: TABLE; Schema: public; Owner: ismael
--

CREATE TABLE public.deputados (
    id_local integer NOT NULL,
    id integer NOT NULL,
    uri character varying NOT NULL,
    nome character varying NOT NULL,
    "siglaPartido" character varying NOT NULL,
    "uriPartido" character varying NOT NULL,
    "siglaUf" character varying NOT NULL,
    "idLegislatura" integer NOT NULL,
    "urlFoto" character varying NOT NULL,
    email character varying
);


ALTER TABLE public.deputados OWNER TO ismael;

--
-- Name: deputados_id_local_seq; Type: SEQUENCE; Schema: public; Owner: ismael
--

CREATE SEQUENCE public.deputados_id_local_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deputados_id_local_seq OWNER TO ismael;

--
-- Name: deputados_id_local_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ismael
--

ALTER SEQUENCE public.deputados_id_local_seq OWNED BY public.deputados.id_local;


--
-- Name: despesas; Type: TABLE; Schema: public; Owner: ismael
--

CREATE TABLE public.despesas (
    id_local integer NOT NULL,
    ano integer NOT NULL,
    mes integer NOT NULL,
    "tipoDespesa" character varying NOT NULL,
    "codDocumento" integer NOT NULL,
    "tipoDocumento" character varying NOT NULL,
    "codTipoDocumento" integer NOT NULL,
    "dataDocumento" character varying NOT NULL,
    "numDocumento" character varying NOT NULL,
    "valorDocumento" numeric(10,2) NOT NULL,
    "urlDocumento" character varying,
    "nomeFornecedor" character varying NOT NULL,
    "cnpjCpfFornecedor" character varying,
    "valorLiquido" numeric(10,2) NOT NULL,
    "valorGlosa" numeric(10,2) NOT NULL,
    "numRessarcimento" character varying,
    "codLote" integer NOT NULL,
    parcela integer NOT NULL,
    "deputadoId" integer NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.despesas OWNER TO ismael;

--
-- Name: despesas_id_local_seq; Type: SEQUENCE; Schema: public; Owner: ismael
--

CREATE SEQUENCE public.despesas_id_local_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.despesas_id_local_seq OWNER TO ismael;

--
-- Name: despesas_id_local_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ismael
--

ALTER SEQUENCE public.despesas_id_local_seq OWNED BY public.despesas.id_local;


--
-- Name: deputados id_local; Type: DEFAULT; Schema: public; Owner: ismael
--

ALTER TABLE ONLY public.deputados ALTER COLUMN id_local SET DEFAULT nextval('public.deputados_id_local_seq'::regclass);


--
-- Name: despesas id_local; Type: DEFAULT; Schema: public; Owner: ismael
--

ALTER TABLE ONLY public.despesas ALTER COLUMN id_local SET DEFAULT nextval('public.despesas_id_local_seq'::regclass);


--
-- Data for Name: deputados; Type: TABLE DATA; Schema: public; Owner: ismael
--

COPY public.deputados (id_local, id, uri, nome, "siglaPartido", "uriPartido", "siglaUf", "idLegislatura", "urlFoto", email) FROM stdin;
3	123	http://exemplo.com	Deputado Exemplo	ABC	http://partido.com	SP	56	http://foto.com	email@exemplo.com
35	221328	https://dadosabertos.camara.leg.br/api/v2/deputados/221328	Adilson Barroso	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/221328.jpg	dep.adilsonbarroso@camara.leg.br
5	1234	http://exemplo.com	Deputado Exemplo 4	ABC	http://partido.com	SP	56	http://foto.com	email@exemplo.com
36	204560	https://dadosabertos.camara.leg.br/api/v2/deputados/204560	Adolfo Viana	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	BA	57	https://www.camara.leg.br/internet/deputado/bandep/204560.jpg	dep.adolfoviana@camara.leg.br
116	204572	https://dadosabertos.camara.leg.br/api/v2/deputados/204572	Capitão Alberto Neto	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	AM	57	https://www.camara.leg.br/internet/deputado/bandep/204572.jpg	dep.capitaoalbertoneto@camara.leg.br
212	220573	https://dadosabertos.camara.leg.br/api/v2/deputados/220573	Dorinaldo Malafaia	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	AP	57	https://www.camara.leg.br/internet/deputado/bandep/220573.jpg	dep.dorinaldomalafaia@camara.leg.br
405	204536	https://dadosabertos.camara.leg.br/api/v2/deputados/204536	Kim Kataguiri	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204536.jpg	dep.kimkataguiri@camara.leg.br
460	179000	https://dadosabertos.camara.leg.br/api/v2/deputados/179000	Marcelo Álvaro Antônio	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/179000.jpg	dep.marceloalvaroantonio@camara.leg.br
32	220593	https://dadosabertos.camara.leg.br/api/v2/deputados/220593	Abilio Brunini	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MT	57	https://www.camara.leg.br/internet/deputado/bandep/220593.jpg	\N
33	204379	https://dadosabertos.camara.leg.br/api/v2/deputados/204379	Acácio Favacho	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	AP	57	https://www.camara.leg.br/internet/deputado/bandep/204379.jpg	dep.acaciofavacho@camara.leg.br
34	220714	https://dadosabertos.camara.leg.br/api/v2/deputados/220714	Adail Filho	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	AM	57	https://www.camara.leg.br/internet/deputado/bandep/220714.jpg	dep.adailfilho@camara.leg.br
53	220542	https://dadosabertos.camara.leg.br/api/v2/deputados/220542	Alexandre Guimarães	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	TO	57	https://www.camara.leg.br/internet/deputado/bandep/220542.jpg	dep.alexandreguimaraes@camara.leg.br
65	178881	https://dadosabertos.camara.leg.br/api/v2/deputados/178881	Aluisio Mendes	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	MA	57	https://www.camara.leg.br/internet/deputado/bandep/178881.jpg	dep.aluisiomendes@camara.leg.br
64	178937	https://dadosabertos.camara.leg.br/api/v2/deputados/178937	Altineu Côrtes	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/178937.jpg	dep.altineucortes@camara.leg.br
39	74646	https://dadosabertos.camara.leg.br/api/v2/deputados/74646	Aécio Neves	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	MG	57	https://www.camara.leg.br/internet/deputado/bandep/74646.jpg	dep.aecioneves@camara.leg.br
40	160508	https://dadosabertos.camara.leg.br/api/v2/deputados/160508	Afonso Florence	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	BA	57	https://www.camara.leg.br/internet/deputado/bandep/160508.jpg	\N
41	136811	https://dadosabertos.camara.leg.br/api/v2/deputados/136811	Afonso Hamm	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	RS	57	https://www.camara.leg.br/internet/deputado/bandep/136811.jpg	dep.afonsohamm@camara.leg.br
42	178835	https://dadosabertos.camara.leg.br/api/v2/deputados/178835	Afonso Motta	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	RS	57	https://www.camara.leg.br/internet/deputado/bandep/178835.jpg	dep.afonsomotta@camara.leg.br
43	160527	https://dadosabertos.camara.leg.br/api/v2/deputados/160527	Aguinaldo Ribeiro	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PB	57	https://www.camara.leg.br/internet/deputado/bandep/160527.jpg	dep.aguinaldoribeiro@camara.leg.br
44	204495	https://dadosabertos.camara.leg.br/api/v2/deputados/204495	Airton Faleiro	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PA	57	https://www.camara.leg.br/internet/deputado/bandep/204495.jpg	dep.airtonfaleiro@camara.leg.br
45	204549	https://dadosabertos.camara.leg.br/api/v2/deputados/204549	AJ Albuquerque	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	CE	57	https://www.camara.leg.br/internet/deputado/bandep/204549.jpg	dep.ajalbuquerque@camara.leg.br
46	73579	https://dadosabertos.camara.leg.br/api/v2/deputados/73579	Alberto Fraga	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	DF	57	https://www.camara.leg.br/internet/deputado/bandep/73579.jpg	dep.albertofraga@camara.leg.br
47	74696	https://dadosabertos.camara.leg.br/api/v2/deputados/74696	Alberto Mourão	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	SP	57	https://www.camara.leg.br/internet/deputado/bandep/74696.jpg	\N
48	220538	https://dadosabertos.camara.leg.br/api/v2/deputados/220538	Albuquerque	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RR	57	https://www.camara.leg.br/internet/deputado/bandep/220538.jpg	dep.albuquerque@camara.leg.br
49	160559	https://dadosabertos.camara.leg.br/api/v2/deputados/160559	Alceu Moreira	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	RS	57	https://www.camara.leg.br/internet/deputado/bandep/160559.jpg	dep.alceumoreira@camara.leg.br
50	204501	https://dadosabertos.camara.leg.br/api/v2/deputados/204501	Alencar Santana	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204501.jpg	dep.alencarsantana@camara.leg.br
51	178972	https://dadosabertos.camara.leg.br/api/v2/deputados/178972	Alex Manente	CIDADANIA	https://dadosabertos.camara.leg.br/api/v2/partidos/37905	SP	57	https://www.camara.leg.br/internet/deputado/bandep/178972.jpg	dep.alexmanente@camara.leg.br
52	204571	https://dadosabertos.camara.leg.br/api/v2/deputados/204571	Alex Santana	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	BA	57	https://www.camara.leg.br/internet/deputado/bandep/204571.jpg	dep.alexsantana@camara.leg.br
55	160545	https://dadosabertos.camara.leg.br/api/v2/deputados/160545	Alexandre Leite	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SP	57	https://www.camara.leg.br/internet/deputado/bandep/160545.jpg	\N
56	220554	https://dadosabertos.camara.leg.br/api/v2/deputados/220554	Alexandre Lindenmeyer	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RS	57	https://www.camara.leg.br/internet/deputado/bandep/220554.jpg	dep.alexandrelindenmeyer@camara.leg.br
57	204503	https://dadosabertos.camara.leg.br/api/v2/deputados/204503	Alexandre Padilha	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204503.jpg	\N
58	221148	https://dadosabertos.camara.leg.br/api/v2/deputados/221148	Alfredinho	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/221148.jpg	dep.alfredinho@camara.leg.br
59	220576	https://dadosabertos.camara.leg.br/api/v2/deputados/220576	Alfredo Gaspar	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	AL	57	https://www.camara.leg.br/internet/deputado/bandep/220576.jpg	dep.alfredogaspar@camara.leg.br
60	74057	https://dadosabertos.camara.leg.br/api/v2/deputados/74057	Alice Portugal	PCdoB	https://dadosabertos.camara.leg.br/api/v2/partidos/36779	BA	57	https://www.camara.leg.br/internet/deputado/bandep/74057.jpg	dep.aliceportugal@camara.leg.br
61	178927	https://dadosabertos.camara.leg.br/api/v2/deputados/178927	Aliel Machado	PV	https://dadosabertos.camara.leg.br/api/v2/partidos/36851	PR	57	https://www.camara.leg.br/internet/deputado/bandep/178927.jpg	dep.alielmachado@camara.leg.br
62	204353	https://dadosabertos.camara.leg.br/api/v2/deputados/204353	Aline Gurgel	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	AP	57	https://www.camara.leg.br/internet/deputado/bandep/204353.jpg	dep.alinegurgel@camara.leg.br
37	204528	https://dadosabertos.camara.leg.br/api/v2/deputados/204528	Adriana Ventura	NOVO	https://dadosabertos.camara.leg.br/api/v2/partidos/37901	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204528.jpg	dep.adrianaventura@camara.leg.br
38	121948	https://dadosabertos.camara.leg.br/api/v2/deputados/121948	Adriano do Baldy	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	GO	57	https://www.camara.leg.br/internet/deputado/bandep/121948.jpg	dep.adrianodobaldy@camara.leg.br
63	226708	https://dadosabertos.camara.leg.br/api/v2/deputados/226708	Dr. Allan Garcês	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	MA	57	https://www.camara.leg.br/internet/deputado/bandep/226708.jpg	dep.allangarces@camara.leg.br
94	220577	https://dadosabertos.camara.leg.br/api/v2/deputados/220577	Augusto Puppio	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	AP	57	https://www.camara.leg.br/internet/deputado/bandep/220577.jpg	\N
69	204356	https://dadosabertos.camara.leg.br/api/v2/deputados/204356	Amaro Neto	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	ES	57	https://www.camara.leg.br/internet/deputado/bandep/204356.jpg	dep.amaroneto@camara.leg.br
70	220715	https://dadosabertos.camara.leg.br/api/v2/deputados/220715	Amom Mandel	CIDADANIA	https://dadosabertos.camara.leg.br/api/v2/partidos/37905	AM	57	https://www.camara.leg.br/internet/deputado/bandep/220715.jpg	dep.amommandel@camara.leg.br
71	107970	https://dadosabertos.camara.leg.br/api/v2/deputados/107970	Ana Paula Leão	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	MG	57	https://www.camara.leg.br/internet/deputado/bandep/107970.jpg	dep.anapaulaleao@camara.leg.br
72	220556	https://dadosabertos.camara.leg.br/api/v2/deputados/220556	Ana Paula Lima	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SC	57	https://www.camara.leg.br/internet/deputado/bandep/220556.jpg	dep.anapaulalima@camara.leg.br
73	220632	https://dadosabertos.camara.leg.br/api/v2/deputados/220632	Ana Pimentel	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MG	57	https://www.camara.leg.br/internet/deputado/bandep/220632.jpg	dep.anapimentel@camara.leg.br
74	178831	https://dadosabertos.camara.leg.br/api/v2/deputados/178831	ANDRÉ ABDON	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	AP	57	https://www.camara.leg.br/internet/deputado/bandep/178831.jpg	dep.andreabdon@camara.leg.br
75	220657	https://dadosabertos.camara.leg.br/api/v2/deputados/220657	André Fernandes	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	CE	57	https://www.camara.leg.br/internet/deputado/bandep/220657.jpg	dep.andrefernandes@camara.leg.br
76	204423	https://dadosabertos.camara.leg.br/api/v2/deputados/204423	André Ferreira	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PE	57	https://www.camara.leg.br/internet/deputado/bandep/204423.jpg	dep.andreferreira@camara.leg.br
77	133439	https://dadosabertos.camara.leg.br/api/v2/deputados/133439	André Figueiredo	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	CE	57	https://www.camara.leg.br/internet/deputado/bandep/133439.jpg	dep.andrefigueiredo@camara.leg.br
78	178882	https://dadosabertos.camara.leg.br/api/v2/deputados/178882	André Fufuca	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	MA	57	https://www.camara.leg.br/internet/deputado/bandep/178882.jpg	\N
79	204515	https://dadosabertos.camara.leg.br/api/v2/deputados/204515	André Janones	AVANTE	https://dadosabertos.camara.leg.br/api/v2/partidos/36898	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204515.jpg	\N
80	220676	https://dadosabertos.camara.leg.br/api/v2/deputados/220676	Andreia Siqueira	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PA	57	https://www.camara.leg.br/internet/deputado/bandep/220676.jpg	dep.andreiasiqueira@camara.leg.br
81	123756	https://dadosabertos.camara.leg.br/api/v2/deputados/123756	Antônia Lúcia	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	AC	57	https://www.camara.leg.br/internet/deputado/bandep/123756.jpg	dep.antonialucia@camara.leg.br
82	220544	https://dadosabertos.camara.leg.br/api/v2/deputados/220544	Antonio Andrade	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	TO	57	https://www.camara.leg.br/internet/deputado/bandep/220544.jpg	dep.antonioandrade@camara.leg.br
83	160553	https://dadosabertos.camara.leg.br/api/v2/deputados/160553	Antonio Brito	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	BA	57	https://www.camara.leg.br/internet/deputado/bandep/160553.jpg	dep.antoniobrito@camara.leg.br
84	220638	https://dadosabertos.camara.leg.br/api/v2/deputados/220638	Antonio Carlos Rodrigues	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220638.jpg	dep.antoniocarlosrodrigues@camara.leg.br
85	220675	https://dadosabertos.camara.leg.br/api/v2/deputados/220675	Antônio Doido	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PA	57	https://www.camara.leg.br/internet/deputado/bandep/220675.jpg	dep.antoniodoido@camara.leg.br
86	220549	https://dadosabertos.camara.leg.br/api/v2/deputados/220549	Any Ortiz	CIDADANIA	https://dadosabertos.camara.leg.br/api/v2/partidos/37905	RS	57	https://www.camara.leg.br/internet/deputado/bandep/220549.jpg	dep.anyortiz@camara.leg.br
87	73433	https://dadosabertos.camara.leg.br/api/v2/deputados/73433	Arlindo Chinaglia	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/73433.jpg	dep.arlindochinaglia@camara.leg.br
88	141391	https://dadosabertos.camara.leg.br/api/v2/deputados/141391	Arnaldo Jardim	CIDADANIA	https://dadosabertos.camara.leg.br/api/v2/partidos/37905	SP	57	https://www.camara.leg.br/internet/deputado/bandep/141391.jpg	dep.arnaldojardim@camara.leg.br
89	160541	https://dadosabertos.camara.leg.br/api/v2/deputados/160541	Arthur Lira	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	AL	57	https://www.camara.leg.br/internet/deputado/bandep/160541.jpg	dep.arthurlira@camara.leg.br
90	160600	https://dadosabertos.camara.leg.br/api/v2/deputados/160600	Arthur Oliveira Maia	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	BA	57	https://www.camara.leg.br/internet/deputado/bandep/160600.jpg	dep.arthuroliveiramaia@camara.leg.br
91	74090	https://dadosabertos.camara.leg.br/api/v2/deputados/74090	Átila Lins	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	AM	57	https://www.camara.leg.br/internet/deputado/bandep/74090.jpg	dep.atilalins@camara.leg.br
92	123086	https://dadosabertos.camara.leg.br/api/v2/deputados/123086	Átila Lira	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PI	57	https://www.camara.leg.br/internet/deputado/bandep/123086.jpg	dep.atilalira@camara.leg.br
93	160665	https://dadosabertos.camara.leg.br/api/v2/deputados/160665	Augusto Coutinho	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	PE	57	https://www.camara.leg.br/internet/deputado/bandep/160665.jpg	dep.augustocoutinho@camara.leg.br
67	220596	https://dadosabertos.camara.leg.br/api/v2/deputados/220596	Amália Barros	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MT	57	https://www.camara.leg.br/internet/deputado/bandep/220596.jpg	\N
68	220707	https://dadosabertos.camara.leg.br/api/v2/deputados/220707	Amanda Gentil	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	MA	57	https://www.camara.leg.br/internet/deputado/bandep/220707.jpg	dep.amandagentil@camara.leg.br
100	220612	https://dadosabertos.camara.leg.br/api/v2/deputados/220612	Bebeto	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220612.jpg	dep.bebeto@camara.leg.br
98	178975	https://dadosabertos.camara.leg.br/api/v2/deputados/178975	Baleia Rossi	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	SP	57	https://www.camara.leg.br/internet/deputado/bandep/178975.jpg	dep.baleiarossi@camara.leg.br
99	220605	https://dadosabertos.camara.leg.br/api/v2/deputados/220605	Bandeira de Mello	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220605.jpg	dep.bandeirademello@camara.leg.br
102	73701	https://dadosabertos.camara.leg.br/api/v2/deputados/73701	Benedita da Silva	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/73701.jpg	dep.beneditadasilva@camara.leg.br
103	109429	https://dadosabertos.camara.leg.br/api/v2/deputados/109429	Benes Leocádio	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RN	57	https://www.camara.leg.br/internet/deputado/bandep/109429.jpg	dep.benesleocadio@camara.leg.br
104	204358	https://dadosabertos.camara.leg.br/api/v2/deputados/204358	Beto Pereira	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	MS	57	https://www.camara.leg.br/internet/deputado/bandep/204358.jpg	dep.betopereira@camara.leg.br
105	220698	https://dadosabertos.camara.leg.br/api/v2/deputados/220698	Beto Preto	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PR	57	https://www.camara.leg.br/internet/deputado/bandep/220698.jpg	\N
106	220683	https://dadosabertos.camara.leg.br/api/v2/deputados/220683	Beto Richa	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	PR	57	https://www.camara.leg.br/internet/deputado/bandep/220683.jpg	dep.betoricha@camara.leg.br
107	204374	https://dadosabertos.camara.leg.br/api/v2/deputados/204374	Bia Kicis	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	DF	57	https://www.camara.leg.br/internet/deputado/bandep/204374.jpg	dep.biakicis@camara.leg.br
108	204388	https://dadosabertos.camara.leg.br/api/v2/deputados/204388	Bibo Nunes	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RS	57	https://www.camara.leg.br/internet/deputado/bandep/204388.jpg	dep.bibonunes@camara.leg.br
109	160538	https://dadosabertos.camara.leg.br/api/v2/deputados/160538	Bohn Gass	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RS	57	https://www.camara.leg.br/internet/deputado/bandep/160538.jpg	dep.bohngass@camara.leg.br
110	74052	https://dadosabertos.camara.leg.br/api/v2/deputados/74052	Bosco Costa	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SE	57	https://www.camara.leg.br/internet/deputado/bandep/74052.jpg	\N
111	210989	https://dadosabertos.camara.leg.br/api/v2/deputados/210989	Bruno Farias	AVANTE	https://dadosabertos.camara.leg.br/api/v2/partidos/36898	MG	57	https://www.camara.leg.br/internet/deputado/bandep/210989.jpg	dep.brunofarias@camara.leg.br
112	220635	https://dadosabertos.camara.leg.br/api/v2/deputados/220635	Bruno Ganem	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220635.jpg	dep.brunoganem@camara.leg.br
113	220574	https://dadosabertos.camara.leg.br/api/v2/deputados/220574	Cabo Gilberto Silva	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PB	57	https://www.camara.leg.br/internet/deputado/bandep/220574.jpg	dep.cabogilbertosilva@camara.leg.br
114	143942	https://dadosabertos.camara.leg.br/api/v2/deputados/143942	Caio Vianna	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/143942.jpg	dep.caiovianna@camara.leg.br
115	220548	https://dadosabertos.camara.leg.br/api/v2/deputados/220548	Camila Jara	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MS	57	https://www.camara.leg.br/internet/deputado/bandep/220548.jpg	dep.camilajara@camara.leg.br
117	220690	https://dadosabertos.camara.leg.br/api/v2/deputados/220690	Capitão Alden	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	BA	57	https://www.camara.leg.br/internet/deputado/bandep/220690.jpg	dep.capitaoalden@camara.leg.br
118	178829	https://dadosabertos.camara.leg.br/api/v2/deputados/178829	Capitão Augusto	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/178829.jpg	dep.capitaoaugusto@camara.leg.br
119	229069	https://dadosabertos.camara.leg.br/api/v2/deputados/229069	Capitão Samuel	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	SE	57	https://www.camara.leg.br/internet/deputado/bandep/229069.jpg	\N
120	229106	https://dadosabertos.camara.leg.br/api/v2/deputados/229106	Carla Ayres	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SC	57	https://www.camara.leg.br/internet/deputado/bandep/229106.jpg	\N
121	213762	https://dadosabertos.camara.leg.br/api/v2/deputados/213762	Carla Dickson	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RN	57	https://www.camara.leg.br/internet/deputado/bandep/213762.jpg	dep.carladickson@camara.leg.br
122	204507	https://dadosabertos.camara.leg.br/api/v2/deputados/204507	Carla Zambelli	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204507.jpg	\N
123	204361	https://dadosabertos.camara.leg.br/api/v2/deputados/204361	Carlos Chiodini	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	SC	57	https://www.camara.leg.br/internet/deputado/bandep/204361.jpg	\N
124	178962	https://dadosabertos.camara.leg.br/api/v2/deputados/178962	Carlos Gomes	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RS	57	https://www.camara.leg.br/internet/deputado/bandep/178962.jpg	\N
125	178993	https://dadosabertos.camara.leg.br/api/v2/deputados/178993	Carlos Henrique Gaguim	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	TO	57	https://www.camara.leg.br/internet/deputado/bandep/178993.jpg	dep.carloshenriquegaguim@camara.leg.br
96	160512	https://dadosabertos.camara.leg.br/api/v2/deputados/160512	Aureo Ribeiro	SOLIDARIEDADE	https://dadosabertos.camara.leg.br/api/v2/partidos/37904	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/160512.jpg	dep.aureoribeiro@camara.leg.br
97	69871	https://dadosabertos.camara.leg.br/api/v2/deputados/69871	Bacelar	PV	https://dadosabertos.camara.leg.br/api/v2/partidos/36851	BA	57	https://www.camara.leg.br/internet/deputado/bandep/69871.jpg	dep.bacelar@camara.leg.br
127	74262	https://dadosabertos.camara.leg.br/api/v2/deputados/74262	Carlos Sampaio	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SP	57	https://www.camara.leg.br/internet/deputado/bandep/74262.jpg	dep.carlossampaio@camara.leg.br
143	204476	https://dadosabertos.camara.leg.br/api/v2/deputados/204476	Chiquinho Brazão	S.PART.	https://dadosabertos.camara.leg.br/api/v2/partidos/36852	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204476.jpg	\N
148	141408	https://dadosabertos.camara.leg.br/api/v2/deputados/141408	Cleber Verde	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	MA	57	https://www.camara.leg.br/internet/deputado/bandep/141408.jpg	dep.cleberverde@camara.leg.br
152	204376	https://dadosabertos.camara.leg.br/api/v2/deputados/204376	Coronel Armando	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	SC	57	https://www.camara.leg.br/internet/deputado/bandep/204376.jpg	\N
130	141398	https://dadosabertos.camara.leg.br/api/v2/deputados/141398	Carlos Zarattini	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/141398.jpg	dep.carloszarattini@camara.leg.br
131	164360	https://dadosabertos.camara.leg.br/api/v2/deputados/164360	Carmen Zanotto	CIDADANIA	https://dadosabertos.camara.leg.br/api/v2/partidos/37905	SC	57	https://www.camara.leg.br/internet/deputado/bandep/164360.jpg	\N
132	220704	https://dadosabertos.camara.leg.br/api/v2/deputados/220704	Carol Dartora	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PR	57	https://www.camara.leg.br/internet/deputado/bandep/220704.jpg	dep.caroldartora@camara.leg.br
133	204369	https://dadosabertos.camara.leg.br/api/v2/deputados/204369	Caroline de Toni	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SC	57	https://www.camara.leg.br/internet/deputado/bandep/204369.jpg	dep.carolinedetoni@camara.leg.br
134	220699	https://dadosabertos.camara.leg.br/api/v2/deputados/220699	Castro Neto	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PI	57	https://www.camara.leg.br/internet/deputado/bandep/220699.jpg	dep.castroneto@camara.leg.br
135	206018	https://dadosabertos.camara.leg.br/api/v2/deputados/206018	Célia Xakriabá	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	MG	57	https://www.camara.leg.br/internet/deputado/bandep/206018.jpg	dep.celiaxakriaba@camara.leg.br
136	178876	https://dadosabertos.camara.leg.br/api/v2/deputados/178876	Célio Silveira	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	GO	57	https://www.camara.leg.br/internet/deputado/bandep/178876.jpg	dep.celiosilveira@camara.leg.br
137	204488	https://dadosabertos.camara.leg.br/api/v2/deputados/204488	Célio Studart	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	CE	57	https://www.camara.leg.br/internet/deputado/bandep/204488.jpg	dep.celiostudart@camara.leg.br
138	73441	https://dadosabertos.camara.leg.br/api/v2/deputados/73441	Celso Russomanno	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	SP	57	https://www.camara.leg.br/internet/deputado/bandep/73441.jpg	dep.celsorussomanno@camara.leg.br
139	204496	https://dadosabertos.camara.leg.br/api/v2/deputados/204496	Celso Sabino	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PA	57	https://www.camara.leg.br/internet/deputado/bandep/204496.jpg	\N
140	204504	https://dadosabertos.camara.leg.br/api/v2/deputados/204504	Cezinha de Madureira	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204504.jpg	dep.cezinhademadureira@camara.leg.br
141	205476	https://dadosabertos.camara.leg.br/api/v2/deputados/205476	Charles Fernandes	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	BA	57	https://www.camara.leg.br/internet/deputado/bandep/205476.jpg	dep.charlesfernandes@camara.leg.br
142	74171	https://dadosabertos.camara.leg.br/api/v2/deputados/74171	Chico Alencar	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/74171.jpg	dep.chicoalencar@camara.leg.br
145	204462	https://dadosabertos.camara.leg.br/api/v2/deputados/204462	Chris Tonietto	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204462.jpg	dep.christonietto@camara.leg.br
146	220665	https://dadosabertos.camara.leg.br/api/v2/deputados/220665	Clarissa Tércio	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PE	57	https://www.camara.leg.br/internet/deputado/bandep/220665.jpg	dep.clarissatercio@camara.leg.br
147	74537	https://dadosabertos.camara.leg.br/api/v2/deputados/74537	Claudio Cajado	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	BA	57	https://www.camara.leg.br/internet/deputado/bandep/74537.jpg	dep.claudiocajado@camara.leg.br
150	88256	https://dadosabertos.camara.leg.br/api/v2/deputados/88256	Clodoaldo Magalhães	PV	https://dadosabertos.camara.leg.br/api/v2/partidos/36851	PE	57	https://www.camara.leg.br/internet/deputado/bandep/88256.jpg	dep.clodoaldomagalhaes@camara.leg.br
151	98148	https://dadosabertos.camara.leg.br/api/v2/deputados/98148	Cobalchini	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	SC	57	https://www.camara.leg.br/internet/deputado/bandep/98148.jpg	dep.cobalchini@camara.leg.br
154	220594	https://dadosabertos.camara.leg.br/api/v2/deputados/220594	Coronel Assis	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	MT	57	https://www.camara.leg.br/internet/deputado/bandep/220594.jpg	dep.coronelassis@camara.leg.br
155	204378	https://dadosabertos.camara.leg.br/api/v2/deputados/204378	Coronel Chrisóstomo	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RO	57	https://www.camara.leg.br/internet/deputado/bandep/204378.jpg	dep.coronelchrisostomo@camara.leg.br
156	220595	https://dadosabertos.camara.leg.br/api/v2/deputados/220595	Coronel Fernanda	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MT	57	https://www.camara.leg.br/internet/deputado/bandep/220595.jpg	dep.coronelfernanda@camara.leg.br
157	220666	https://dadosabertos.camara.leg.br/api/v2/deputados/220666	Coronel Meira	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PE	57	https://www.camara.leg.br/internet/deputado/bandep/220666.jpg	dep.coronelmeira@camara.leg.br
126	204460	https://dadosabertos.camara.leg.br/api/v2/deputados/204460	Carlos Jordy	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204460.jpg	dep.carlosjordy@camara.leg.br
129	204426	https://dadosabertos.camara.leg.br/api/v2/deputados/204426	Carlos Veras	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PE	57	https://www.camara.leg.br/internet/deputado/bandep/204426.jpg	dep.carlosveras@camara.leg.br
183	220659	https://dadosabertos.camara.leg.br/api/v2/deputados/220659	Dayany do Capitão	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	CE	57	https://www.camara.leg.br/internet/deputado/bandep/220659.jpg	dep.dayanybittencourt@camara.leg.br
178	220557	https://dadosabertos.camara.leg.br/api/v2/deputados/220557	Daniela Reinehr	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SC	57	https://www.camara.leg.br/internet/deputado/bandep/220557.jpg	dep.danielareinehr@camara.leg.br
160	220590	https://dadosabertos.camara.leg.br/api/v2/deputados/220590	Coronel Ulysses	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	AC	57	https://www.camara.leg.br/internet/deputado/bandep/220590.jpg	dep.coronelulysses@camara.leg.br
161	178963	https://dadosabertos.camara.leg.br/api/v2/deputados/178963	Covatti Filho	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	RS	57	https://www.camara.leg.br/internet/deputado/bandep/178963.jpg	dep.covattifilho@camara.leg.br
162	220608	https://dadosabertos.camara.leg.br/api/v2/deputados/220608	Cristiane Lopes	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RO	57	https://www.camara.leg.br/internet/deputado/bandep/220608.jpg	dep.cristianelopes@camara.leg.br
163	204355	https://dadosabertos.camara.leg.br/api/v2/deputados/204355	Da Vitoria	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	ES	57	https://www.camara.leg.br/internet/deputado/bandep/204355.jpg	dep.davitoria@camara.leg.br
164	141411	https://dadosabertos.camara.leg.br/api/v2/deputados/141411	Dagoberto Nogueira	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	MS	57	https://www.camara.leg.br/internet/deputado/bandep/141411.jpg	dep.dagobertonogueira@camara.leg.br
165	220555	https://dadosabertos.camara.leg.br/api/v2/deputados/220555	Daiana Santos	PCdoB	https://dadosabertos.camara.leg.br/api/v2/partidos/36779	RS	57	https://www.camara.leg.br/internet/deputado/bandep/220555.jpg	dep.daianasantos@camara.leg.br
166	220692	https://dadosabertos.camara.leg.br/api/v2/deputados/220692	Dal Barreto	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	BA	57	https://www.camara.leg.br/internet/deputado/bandep/220692.jpg	dep.dalbarreto@camara.leg.br
167	74467	https://dadosabertos.camara.leg.br/api/v2/deputados/74467	Damião Feliciano	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PB	57	https://www.camara.leg.br/internet/deputado/bandep/74467.jpg	dep.damiaofeliciano@camara.leg.br
168	220629	https://dadosabertos.camara.leg.br/api/v2/deputados/220629	Dandara	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MG	57	https://www.camara.leg.br/internet/deputado/bandep/220629.jpg	dep.dandara@camara.leg.br
169	220603	https://dadosabertos.camara.leg.br/api/v2/deputados/220603	Dani Cunha	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220603.jpg	dep.danicunha@camara.leg.br
170	220571	https://dadosabertos.camara.leg.br/api/v2/deputados/220571	Daniel Agrobom	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	GO	57	https://www.camara.leg.br/internet/deputado/bandep/220571.jpg	dep.danielagrobom@camara.leg.br
171	74060	https://dadosabertos.camara.leg.br/api/v2/deputados/74060	Daniel Almeida	PCdoB	https://dadosabertos.camara.leg.br/api/v2/partidos/36779	BA	57	https://www.camara.leg.br/internet/deputado/bandep/74060.jpg	dep.danielalmeida@camara.leg.br
172	220582	https://dadosabertos.camara.leg.br/api/v2/deputados/220582	Daniel Barbosa	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	AL	57	https://www.camara.leg.br/internet/deputado/bandep/220582.jpg	dep.danielbarbosa@camara.leg.br
173	204367	https://dadosabertos.camara.leg.br/api/v2/deputados/204367	Daniel Freitas	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SC	57	https://www.camara.leg.br/internet/deputado/bandep/204367.jpg	dep.danielfreitas@camara.leg.br
174	228941	https://dadosabertos.camara.leg.br/api/v2/deputados/228941	Daniel José	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	SP	57	https://www.camara.leg.br/internet/deputado/bandep/228941.jpg	\N
158	204514	https://dadosabertos.camara.leg.br/api/v2/deputados/204514	Coronel Tadeu	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204514.jpg	\N
159	222142	https://dadosabertos.camara.leg.br/api/v2/deputados/222142	Coronel Telhada	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	SP	57	https://www.camara.leg.br/internet/deputado/bandep/222142.jpg	\N
179	62881	https://dadosabertos.camara.leg.br/api/v2/deputados/62881	Danilo Forte	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	CE	57	https://www.camara.leg.br/internet/deputado/bandep/62881.jpg	dep.daniloforte@camara.leg.br
180	160552	https://dadosabertos.camara.leg.br/api/v2/deputados/160552	Danrlei de Deus Hinterholz	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RS	57	https://www.camara.leg.br/internet/deputado/bandep/160552.jpg	dep.danrleidedeushinterholz@camara.leg.br
181	116379	https://dadosabertos.camara.leg.br/api/v2/deputados/116379	Darci de Matos	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SC	57	https://www.camara.leg.br/internet/deputado/bandep/116379.jpg	\N
182	204511	https://dadosabertos.camara.leg.br/api/v2/deputados/204511	David Soares	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204511.jpg	dep.davidsoares@camara.leg.br
185	220539	https://dadosabertos.camara.leg.br/api/v2/deputados/220539	Defensor Stélio Dener	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RR	57	https://www.camara.leg.br/internet/deputado/bandep/220539.jpg	dep.defensorsteliodener@camara.leg.br
186	220565	https://dadosabertos.camara.leg.br/api/v2/deputados/220565	Delegada Adriana Accorsi	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	GO	57	https://www.camara.leg.br/internet/deputado/bandep/220565.jpg	dep.delegadaadrianaaccorsi@camara.leg.br
175	220614	https://dadosabertos.camara.leg.br/api/v2/deputados/220614	Dr. Daniel Soranz	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220614.jpg	\N
176	204409	https://dadosabertos.camara.leg.br/api/v2/deputados/204409	Daniel Trzeciak	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	RS	57	https://www.camara.leg.br/internet/deputado/bandep/204409.jpg	dep.danieltrzeciak@camara.leg.br
177	204459	https://dadosabertos.camara.leg.br/api/v2/deputados/204459	Daniela do Waguinho	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204459.jpg	dep.danieladowaguinho@camara.leg.br
189	220642	https://dadosabertos.camara.leg.br/api/v2/deputados/220642	Delegado Bruno Lima	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220642.jpg	dep.delegadobrunolima@camara.leg.br
190	220673	https://dadosabertos.camara.leg.br/api/v2/deputados/220673	Delegado Caveira	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PA	57	https://www.camara.leg.br/internet/deputado/bandep/220673.jpg	dep.delegadocaveira@camara.leg.br
191	220649	https://dadosabertos.camara.leg.br/api/v2/deputados/220649	Delegado da Cunha	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220649.jpg	dep.delegadodacunha@camara.leg.br
192	178908	https://dadosabertos.camara.leg.br/api/v2/deputados/178908	Delegado Éder Mauro	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PA	57	https://www.camara.leg.br/internet/deputado/bandep/178908.jpg	dep.delegadoedermauro@camara.leg.br
193	220583	https://dadosabertos.camara.leg.br/api/v2/deputados/220583	Delegado Fabio Costa	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	AL	57	https://www.camara.leg.br/internet/deputado/bandep/220583.jpg	dep.delegadofabiocosta@camara.leg.br
194	204512	https://dadosabertos.camara.leg.br/api/v2/deputados/204512	Delegado Marcelo Freitas	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204512.jpg	dep.delegadomarcelofreitas@camara.leg.br
195	220701	https://dadosabertos.camara.leg.br/api/v2/deputados/220701	Delegado Matheus Laiola	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PR	57	https://www.camara.leg.br/internet/deputado/bandep/220701.jpg	dep.delegadomatheuslaiola@camara.leg.br
196	220652	https://dadosabertos.camara.leg.br/api/v2/deputados/220652	Delegado Palumbo	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220652.jpg	dep.delegadopalumbo@camara.leg.br
197	220654	https://dadosabertos.camara.leg.br/api/v2/deputados/220654	Delegado Paulo Bilynskyj	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220654.jpg	dep.delegadopaulobilynskyj@camara.leg.br
198	220619	https://dadosabertos.camara.leg.br/api/v2/deputados/220619	Delegado Ramagem	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220619.jpg	dep.delegadoramagem@camara.leg.br
199	228272	https://dadosabertos.camara.leg.br/api/v2/deputados/228272	Délio Pinheiro	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	MG	57	https://www.camara.leg.br/internet/deputado/bandep/228272.jpg	\N
200	220705	https://dadosabertos.camara.leg.br/api/v2/deputados/220705	Deltan Dallagnol	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	PR	57	https://www.camara.leg.br/internet/deputado/bandep/220705.jpg	\N
201	220553	https://dadosabertos.camara.leg.br/api/v2/deputados/220553	Denise Pessôa	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RS	57	https://www.camara.leg.br/internet/deputado/bandep/220553.jpg	dep.denisepessoa@camara.leg.br
202	220689	https://dadosabertos.camara.leg.br/api/v2/deputados/220689	Detinha	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MA	57	https://www.camara.leg.br/internet/deputado/bandep/220689.jpg	dep.detinha@camara.leg.br
203	160588	https://dadosabertos.camara.leg.br/api/v2/deputados/160588	Diego Andrade	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	MG	57	https://www.camara.leg.br/internet/deputado/bandep/160588.jpg	dep.diegoandrade@camara.leg.br
204	220691	https://dadosabertos.camara.leg.br/api/v2/deputados/220691	Diego Coronel	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	BA	57	https://www.camara.leg.br/internet/deputado/bandep/220691.jpg	dep.diegocoronel@camara.leg.br
205	178929	https://dadosabertos.camara.leg.br/api/v2/deputados/178929	Diego Garcia	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	PR	57	https://www.camara.leg.br/internet/deputado/bandep/178929.jpg	dep.diegogarcia@camara.leg.br
206	73768	https://dadosabertos.camara.leg.br/api/v2/deputados/73768	Dilceu Sperafico	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PR	57	https://www.camara.leg.br/internet/deputado/bandep/73768.jpg	dep.dilceusperafico@camara.leg.br
207	220671	https://dadosabertos.camara.leg.br/api/v2/deputados/220671	Dilvanda Faro	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PA	57	https://www.camara.leg.br/internet/deputado/bandep/220671.jpg	dep.dilvandafaro@camara.leg.br
208	160599	https://dadosabertos.camara.leg.br/api/v2/deputados/160599	Dimas Fabiano	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	MG	57	https://www.camara.leg.br/internet/deputado/bandep/160599.jpg	dep.dimasfabiano@camara.leg.br
209	220602	https://dadosabertos.camara.leg.br/api/v2/deputados/220602	Dimas Gadelha	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220602.jpg	dep.dimasgadelha@camara.leg.br
210	143632	https://dadosabertos.camara.leg.br/api/v2/deputados/143632	Domingos Neto	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	CE	57	https://www.camara.leg.br/internet/deputado/bandep/143632.jpg	dep.domingosneto@camara.leg.br
211	160758	https://dadosabertos.camara.leg.br/api/v2/deputados/160758	Domingos Sávio	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/160758.jpg	dep.domingossavio@camara.leg.br
213	227433	https://dadosabertos.camara.leg.br/api/v2/deputados/227433	Douglas Viegas	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SP	57	https://www.camara.leg.br/internet/deputado/bandep/227433.jpg	dep.douglasviegas@camara.leg.br
214	204450	https://dadosabertos.camara.leg.br/api/v2/deputados/204450	Doutor Luizinho	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204450.jpg	dep.doutorluizinho@camara.leg.br
187	220625	https://dadosabertos.camara.leg.br/api/v2/deputados/220625	Delegada Ione	AVANTE	https://dadosabertos.camara.leg.br/api/v2/partidos/36898	MG	57	https://www.camara.leg.br/internet/deputado/bandep/220625.jpg	dep.delegadaione@camara.leg.br
188	220561	https://dadosabertos.camara.leg.br/api/v2/deputados/220561	Delegada Katarina	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SE	57	https://www.camara.leg.br/internet/deputado/bandep/220561.jpg	dep.delegadakatarina@camara.leg.br
223	204518	https://dadosabertos.camara.leg.br/api/v2/deputados/204518	Dr. Frederico	PRD	https://dadosabertos.camara.leg.br/api/v2/partidos/38010	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204518.jpg	dep.dr.frederico@camara.leg.br
229	228616	https://dadosabertos.camara.leg.br/api/v2/deputados/228616	Dr. Remy Soares	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	MA	57	https://www.camara.leg.br/internet/deputado/bandep/228616.jpg	\N
234	220686	https://dadosabertos.camara.leg.br/api/v2/deputados/220686	Duarte Jr.	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	MA	57	https://www.camara.leg.br/internet/deputado/bandep/220686.jpg	dep.duartejr@camara.leg.br
235	227800	https://dadosabertos.camara.leg.br/api/v2/deputados/227800	Duarte Gonçalves Jr	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	MG	57	https://www.camara.leg.br/internet/deputado/bandep/227800.jpg	\N
225	212625	https://dadosabertos.camara.leg.br/api/v2/deputados/212625	Dr. Gonçalo	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	MA	57	https://www.camara.leg.br/internet/deputado/bandep/212625.jpg	\N
215	221339	https://dadosabertos.camara.leg.br/api/v2/deputados/221339	Dr. Benjamim	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	MA	57	https://www.camara.leg.br/internet/deputado/bandep/221339.jpg	\N
216	227401	https://dadosabertos.camara.leg.br/api/v2/deputados/227401	Dr Fabio Rueda	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	AC	57	https://www.camara.leg.br/internet/deputado/bandep/227401.jpg	\N
217	227991	https://dadosabertos.camara.leg.br/api/v2/deputados/227991	Dr Flávio	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/227991.jpg	\N
221	220610	https://dadosabertos.camara.leg.br/api/v2/deputados/220610	Dr. Fernando Máximo	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RO	57	https://www.camara.leg.br/internet/deputado/bandep/220610.jpg	dep.dr.fernandomaximo@camara.leg.br
222	220688	https://dadosabertos.camara.leg.br/api/v2/deputados/220688	Dr. Francisco	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PI	57	https://www.camara.leg.br/internet/deputado/bandep/220688.jpg	dep.dr.francisco@camara.leg.br
230	220528	https://dadosabertos.camara.leg.br/api/v2/deputados/220528	Dr. Victor Linhalis	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	ES	57	https://www.camara.leg.br/internet/deputado/bandep/220528.jpg	dep.dr.victorlinhalis@camara.leg.br
231	204412	https://dadosabertos.camara.leg.br/api/v2/deputados/204412	Dr. Zacharias Calil	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	GO	57	https://www.camara.leg.br/internet/deputado/bandep/204412.jpg	dep.dr.zachariascalil@camara.leg.br
232	220674	https://dadosabertos.camara.leg.br/api/v2/deputados/220674	Dra. Alessandra Haber	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PA	57	https://www.camara.leg.br/internet/deputado/bandep/220674.jpg	dep.dra.alessandrahaber@camara.leg.br
233	230088	https://dadosabertos.camara.leg.br/api/v2/deputados/230088	Dra. Mayra Pinheiro	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	CE	57	https://www.camara.leg.br/internet/deputado/bandep/230088.jpg	\N
239	220540	https://dadosabertos.camara.leg.br/api/v2/deputados/220540	Duda Ramos	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	RR	57	https://www.camara.leg.br/internet/deputado/bandep/220540.jpg	dep.dudaramos@camara.leg.br
240	220623	https://dadosabertos.camara.leg.br/api/v2/deputados/220623	Duda Salabert	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	MG	57	https://www.camara.leg.br/internet/deputado/bandep/220623.jpg	dep.dudasalabert@camara.leg.br
241	204541	https://dadosabertos.camara.leg.br/api/v2/deputados/204541	Eduardo Bismarck	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	CE	57	https://www.camara.leg.br/internet/deputado/bandep/204541.jpg	\N
242	92346	https://dadosabertos.camara.leg.br/api/v2/deputados/92346	Eduardo Bolsonaro	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/92346.jpg	dep.eduardobolsonaro@camara.leg.br
243	141421	https://dadosabertos.camara.leg.br/api/v2/deputados/141421	Eduardo da Fonte	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PE	57	https://www.camara.leg.br/internet/deputado/bandep/141421.jpg	dep.eduardodafonte@camara.leg.br
244	220589	https://dadosabertos.camara.leg.br/api/v2/deputados/220589	Eduardo Velloso	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	AC	57	https://www.camara.leg.br/internet/deputado/bandep/220589.jpg	dep.eduardovelloso@camara.leg.br
245	74075	https://dadosabertos.camara.leg.br/api/v2/deputados/74075	Elcione Barbalho	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PA	57	https://www.camara.leg.br/internet/deputado/bandep/74075.jpg	dep.elcionebarbalho@camara.leg.br
246	204364	https://dadosabertos.camara.leg.br/api/v2/deputados/204364	Eli Borges	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	TO	57	https://www.camara.leg.br/internet/deputado/bandep/204364.jpg	dep.eliborges@camara.leg.br
247	226553	https://dadosabertos.camara.leg.br/api/v2/deputados/226553	Eliane Braz	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	CE	57	https://www.camara.leg.br/internet/deputado/bandep/226553.jpg	\N
226	220570	https://dadosabertos.camara.leg.br/api/v2/deputados/220570	Ismael Alexandrino	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	GO	57	https://www.camara.leg.br/internet/deputado/bandep/220570.jpg	dep.dr.ismaelalexandrino@camara.leg.br
227	204481	https://dadosabertos.camara.leg.br/api/v2/deputados/204481	Dr. Jaziel	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	CE	57	https://www.camara.leg.br/internet/deputado/bandep/204481.jpg	dep.dr.jaziel@camara.leg.br
228	204351	https://dadosabertos.camara.leg.br/api/v2/deputados/204351	Dr. Luiz Ovando	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	MS	57	https://www.camara.leg.br/internet/deputado/bandep/204351.jpg	dep.dr.luizovando@camara.leg.br
254	225730	https://dadosabertos.camara.leg.br/api/v2/deputados/225730	Enfermeira Ana Paula	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	CE	57	https://www.camara.leg.br/internet/deputado/bandep/225730.jpg	dep.enfermeiraanapaula@camara.leg.br
262	204482	https://dadosabertos.camara.leg.br/api/v2/deputados/204482	Euclydes Pettersen	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204482.jpg	dep.euclydespettersen@camara.leg.br
250	178854	https://dadosabertos.camara.leg.br/api/v2/deputados/178854	Elmar Nascimento	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	BA	57	https://www.camara.leg.br/internet/deputado/bandep/178854.jpg	dep.elmarnascimento@camara.leg.br
251	218086	https://dadosabertos.camara.leg.br/api/v2/deputados/218086	Ely Santos	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	SP	57	https://www.camara.leg.br/internet/deputado/bandep/218086.jpg	dep.elysantos@camara.leg.br
252	198783	https://dadosabertos.camara.leg.br/api/v2/deputados/198783	Emanuel Pinheiro Neto	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	MT	57	https://www.camara.leg.br/internet/deputado/bandep/198783.jpg	dep.emanuelpinheironeto@camara.leg.br
253	161550	https://dadosabertos.camara.leg.br/api/v2/deputados/161550	Emidinho Madeira	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/161550.jpg	dep.emidinhomadeira@camara.leg.br
256	230765	https://dadosabertos.camara.leg.br/api/v2/deputados/230765	Enfermeira Rejane	PCdoB	https://dadosabertos.camara.leg.br/api/v2/partidos/36779	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/230765.jpg	dep.enfermeirarejane@camara.leg.br
257	132504	https://dadosabertos.camara.leg.br/api/v2/deputados/132504	Enio Verri	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PR	57	https://www.camara.leg.br/internet/deputado/bandep/132504.jpg	\N
258	220663	https://dadosabertos.camara.leg.br/api/v2/deputados/220663	Eriberto Medeiros	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	PE	57	https://www.camara.leg.br/internet/deputado/bandep/220663.jpg	dep.eribertomedeiros@camara.leg.br
259	220645	https://dadosabertos.camara.leg.br/api/v2/deputados/220645	Erika Hilton	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220645.jpg	dep.erikahilton@camara.leg.br
260	160575	https://dadosabertos.camara.leg.br/api/v2/deputados/160575	Erika Kokay	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	DF	57	https://www.camara.leg.br/internet/deputado/bandep/160575.jpg	dep.erikakokay@camara.leg.br
261	160640	https://dadosabertos.camara.leg.br/api/v2/deputados/160640	Eros Biondini	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/160640.jpg	dep.erosbiondini@camara.leg.br
264	74454	https://dadosabertos.camara.leg.br/api/v2/deputados/74454	Eunício Oliveira	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	CE	57	https://www.camara.leg.br/internet/deputado/bandep/74454.jpg	\N
265	178871	https://dadosabertos.camara.leg.br/api/v2/deputados/178871	Evair Vieira de Melo	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	ES	57	https://www.camara.leg.br/internet/deputado/bandep/178871.jpg	dep.evairvieirademelo@camara.leg.br
266	178905	https://dadosabertos.camara.leg.br/api/v2/deputados/178905	Fabio Garcia	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	MT	57	https://www.camara.leg.br/internet/deputado/bandep/178905.jpg	\N
267	68720	https://dadosabertos.camara.leg.br/api/v2/deputados/68720	Fábio Henrique	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SE	57	https://www.camara.leg.br/internet/deputado/bandep/68720.jpg	\N
268	220681	https://dadosabertos.camara.leg.br/api/v2/deputados/220681	Fábio Macedo	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	MA	57	https://www.camara.leg.br/internet/deputado/bandep/220681.jpg	dep.fabiomacedo@camara.leg.br
269	171623	https://dadosabertos.camara.leg.br/api/v2/deputados/171623	Fabio Reis	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SE	57	https://www.camara.leg.br/internet/deputado/bandep/171623.jpg	dep.fabioreis@camara.leg.br
270	204368	https://dadosabertos.camara.leg.br/api/v2/deputados/204368	Fabio Schiochet	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SC	57	https://www.camara.leg.br/internet/deputado/bandep/204368.jpg	dep.fabioschiochet@camara.leg.br
271	220653	https://dadosabertos.camara.leg.br/api/v2/deputados/220653	Fábio Teruel	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220653.jpg	dep.fabioteruel@camara.leg.br
272	66828	https://dadosabertos.camara.leg.br/api/v2/deputados/66828	Fausto Pinato	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	SP	57	https://www.camara.leg.br/internet/deputado/bandep/66828.jpg	dep.faustopinato@camara.leg.br
273	220712	https://dadosabertos.camara.leg.br/api/v2/deputados/220712	Fausto Santos Jr.	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	AM	57	https://www.camara.leg.br/internet/deputado/bandep/220712.jpg	dep.faustosantosjr@camara.leg.br
274	220646	https://dadosabertos.camara.leg.br/api/v2/deputados/220646	Felipe Becari	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220646.jpg	dep.felipebecari@camara.leg.br
275	72442	https://dadosabertos.camara.leg.br/api/v2/deputados/72442	Felipe Carreras	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	PE	57	https://www.camara.leg.br/internet/deputado/bandep/72442.jpg	dep.felipecarreras@camara.leg.br
276	204398	https://dadosabertos.camara.leg.br/api/v2/deputados/204398	Felipe Francischini	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PR	57	https://www.camara.leg.br/internet/deputado/bandep/204398.jpg	dep.felipefrancischini@camara.leg.br
248	229585	https://dadosabertos.camara.leg.br/api/v2/deputados/229585	Elisangela Araujo	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	BA	57	https://www.camara.leg.br/internet/deputado/bandep/229585.jpg	\N
249	220008	https://dadosabertos.camara.leg.br/api/v2/deputados/220008	Eliza Virgínia	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PB	57	https://www.camara.leg.br/internet/deputado/bandep/220008.jpg	\N
277	227370	https://dadosabertos.camara.leg.br/api/v2/deputados/227370	Felipe Saliba	PRD	https://dadosabertos.camara.leg.br/api/v2/partidos/38010	MG	57	https://www.camara.leg.br/internet/deputado/bandep/227370.jpg	\N
284	92699	https://dadosabertos.camara.leg.br/api/v2/deputados/92699	Fernando Monteiro	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	PE	57	https://www.camara.leg.br/internet/deputado/bandep/92699.jpg	dep.fernandomonteiro@camara.leg.br
294	204494	https://dadosabertos.camara.leg.br/api/v2/deputados/204494	Fred Costa	PRD	https://dadosabertos.camara.leg.br/api/v2/partidos/38010	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204494.jpg	dep.fredcosta@camara.leg.br
281	220656	https://dadosabertos.camara.leg.br/api/v2/deputados/220656	Fernanda Pessoa	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	CE	57	https://www.camara.leg.br/internet/deputado/bandep/220656.jpg	dep.fernandapessoa@camara.leg.br
282	141431	https://dadosabertos.camara.leg.br/api/v2/deputados/141431	Fernando Coelho Filho	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PE	57	https://www.camara.leg.br/internet/deputado/bandep/141431.jpg	dep.fernandocoelhofilho@camara.leg.br
283	204445	https://dadosabertos.camara.leg.br/api/v2/deputados/204445	Fernando Mineiro	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RN	57	https://www.camara.leg.br/internet/deputado/bandep/204445.jpg	dep.fernandomineiro@camara.leg.br
286	204427	https://dadosabertos.camara.leg.br/api/v2/deputados/204427	Fernando Rodolfo	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PE	57	https://www.camara.leg.br/internet/deputado/bandep/204427.jpg	dep.fernandorodolfo@camara.leg.br
287	204411	https://dadosabertos.camara.leg.br/api/v2/deputados/204411	Filipe Barros	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PR	57	https://www.camara.leg.br/internet/deputado/bandep/204411.jpg	dep.filipebarros@camara.leg.br
288	220545	https://dadosabertos.camara.leg.br/api/v2/deputados/220545	Filipe Martins	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	TO	57	https://www.camara.leg.br/internet/deputado/bandep/220545.jpg	dep.filipemartins@camara.leg.br
289	160598	https://dadosabertos.camara.leg.br/api/v2/deputados/160598	Flávia Morais	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	GO	57	https://www.camara.leg.br/internet/deputado/bandep/160598.jpg	dep.flaviamorais@camara.leg.br
290	225727	https://dadosabertos.camara.leg.br/api/v2/deputados/225727	Flavinha	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	MT	57	https://www.camara.leg.br/internet/deputado/bandep/225727.jpg	\N
291	191923	https://dadosabertos.camara.leg.br/api/v2/deputados/191923	Flávio Nogueira	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PI	57	https://www.camara.leg.br/internet/deputado/bandep/191923.jpg	dep.flavionogueira@camara.leg.br
292	220700	https://dadosabertos.camara.leg.br/api/v2/deputados/220700	Florentino Neto	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PI	57	https://www.camara.leg.br/internet/deputado/bandep/220700.jpg	dep.florentinoneto@camara.leg.br
293	220551	https://dadosabertos.camara.leg.br/api/v2/deputados/220551	Franciane Bayer	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RS	57	https://www.camara.leg.br/internet/deputado/bandep/220551.jpg	dep.francianebayer@camara.leg.br
296	220534	https://dadosabertos.camara.leg.br/api/v2/deputados/220534	Fred Linhares	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	DF	57	https://www.camara.leg.br/internet/deputado/bandep/220534.jpg	dep.fredlinhares@camara.leg.br
297	224117	https://dadosabertos.camara.leg.br/api/v2/deputados/224117	Gabriel Mota	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RR	57	https://www.camara.leg.br/internet/deputado/bandep/224117.jpg	dep.gabrielmota@camara.leg.br
298	220708	https://dadosabertos.camara.leg.br/api/v2/deputados/220708	Gabriel Nunes	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	BA	57	https://www.camara.leg.br/internet/deputado/bandep/220708.jpg	dep.gabrielnunes@camara.leg.br
299	204473	https://dadosabertos.camara.leg.br/api/v2/deputados/204473	General Girão	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RN	57	https://www.camara.leg.br/internet/deputado/bandep/204473.jpg	dep.generalgirao@camara.leg.br
300	220611	https://dadosabertos.camara.leg.br/api/v2/deputados/220611	General Pazuello	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220611.jpg	dep.generalpazuello@camara.leg.br
301	178966	https://dadosabertos.camara.leg.br/api/v2/deputados/178966	Geovania de Sá	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	SC	57	https://www.camara.leg.br/internet/deputado/bandep/178966.jpg	dep.geovaniadesa@camara.leg.br
302	220702	https://dadosabertos.camara.leg.br/api/v2/deputados/220702	Geraldo Mendes	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PR	57	https://www.camara.leg.br/internet/deputado/bandep/220702.jpg	dep.geraldomendes@camara.leg.br
303	74374	https://dadosabertos.camara.leg.br/api/v2/deputados/74374	Geraldo Resende	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	MS	57	https://www.camara.leg.br/internet/deputado/bandep/74374.jpg	dep.geraldoresende@camara.leg.br
304	220587	https://dadosabertos.camara.leg.br/api/v2/deputados/220587	Gerlen Diniz	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	AC	57	https://www.camara.leg.br/internet/deputado/bandep/220587.jpg	\N
305	204394	https://dadosabertos.camara.leg.br/api/v2/deputados/204394	Gervásio Maia	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	PB	57	https://www.camara.leg.br/internet/deputado/bandep/204394.jpg	dep.gervasiomaia@camara.leg.br
279	160666	https://dadosabertos.camara.leg.br/api/v2/deputados/160666	Félix Mendonça Júnior	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	BA	57	https://www.camara.leg.br/internet/deputado/bandep/160666.jpg	dep.felixmendoncajunior@camara.leg.br
280	204407	https://dadosabertos.camara.leg.br/api/v2/deputados/204407	Fernanda Melchionna	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	RS	57	https://www.camara.leg.br/internet/deputado/bandep/204407.jpg	dep.fernandamelchionna@camara.leg.br
308	74270	https://dadosabertos.camara.leg.br/api/v2/deputados/74270	Gilberto Nascimento	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SP	57	https://www.camara.leg.br/internet/deputado/bandep/74270.jpg	dep.gilbertonascimento@camara.leg.br
318	204419	https://dadosabertos.camara.leg.br/api/v2/deputados/204419	Glaustin da Fokus	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	GO	57	https://www.camara.leg.br/internet/deputado/bandep/204419.jpg	\N
310	220529	https://dadosabertos.camara.leg.br/api/v2/deputados/220529	Gilson Daniel	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	ES	57	https://www.camara.leg.br/internet/deputado/bandep/220529.jpg	dep.gilsondaniel@camara.leg.br
311	204365	https://dadosabertos.camara.leg.br/api/v2/deputados/204365	Gilson Marques	NOVO	https://dadosabertos.camara.leg.br/api/v2/partidos/37901	SC	57	https://www.camara.leg.br/internet/deputado/bandep/204365.jpg	dep.gilsonmarques@camara.leg.br
312	220526	https://dadosabertos.camara.leg.br/api/v2/deputados/220526	Gilvan da Federal	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	ES	57	https://www.camara.leg.br/internet/deputado/bandep/220526.jpg	dep.gilvandafederal@camara.leg.br
313	220531	https://dadosabertos.camara.leg.br/api/v2/deputados/220531	Gilvan Maximo	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	DF	57	https://www.camara.leg.br/internet/deputado/bandep/220531.jpg	\N
314	160673	https://dadosabertos.camara.leg.br/api/v2/deputados/160673	Giovani Cherini	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RS	57	https://www.camara.leg.br/internet/deputado/bandep/160673.jpg	dep.giovanicherini@camara.leg.br
315	226179	https://dadosabertos.camara.leg.br/api/v2/deputados/226179	Gisela Simona	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	MT	57	https://www.camara.leg.br/internet/deputado/bandep/226179.jpg	dep.giselasimona@camara.leg.br
316	152605	https://dadosabertos.camara.leg.br/api/v2/deputados/152605	Glauber Braga	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/152605.jpg	dep.glauberbraga@camara.leg.br
317	229333	https://dadosabertos.camara.leg.br/api/v2/deputados/229333	Gláucia Santiago	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/229333.jpg	\N
320	107283	https://dadosabertos.camara.leg.br/api/v2/deputados/107283	Gleisi Hoffmann	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PR	57	https://www.camara.leg.br/internet/deputado/bandep/107283.jpg	\N
321	198197	https://dadosabertos.camara.leg.br/api/v2/deputados/198197	Greyce Elias	AVANTE	https://dadosabertos.camara.leg.br/api/v2/partidos/36898	MG	57	https://www.camara.leg.br/internet/deputado/bandep/198197.jpg	dep.greyceelias@camara.leg.br
322	220639	https://dadosabertos.camara.leg.br/api/v2/deputados/220639	Guilherme Boulos	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220639.jpg	dep.guilhermeboulos@camara.leg.br
323	204531	https://dadosabertos.camara.leg.br/api/v2/deputados/204531	Guilherme Derrite	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204531.jpg	\N
324	220664	https://dadosabertos.camara.leg.br/api/v2/deputados/220664	Guilherme Uchoa	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	PE	57	https://www.camara.leg.br/internet/deputado/bandep/220664.jpg	dep.guilhermeuchoa@camara.leg.br
325	220568	https://dadosabertos.camara.leg.br/api/v2/deputados/220568	Gustavo Gayer	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	GO	57	https://www.camara.leg.br/internet/deputado/bandep/220568.jpg	dep.gustavogayer@camara.leg.br
326	204408	https://dadosabertos.camara.leg.br/api/v2/deputados/204408	Gustinho Ribeiro	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	SE	57	https://www.camara.leg.br/internet/deputado/bandep/204408.jpg	dep.gustinhoribeiro@camara.leg.br
327	204456	https://dadosabertos.camara.leg.br/api/v2/deputados/204456	Gutemberg Reis	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204456.jpg	dep.gutembergreis@camara.leg.br
328	178964	https://dadosabertos.camara.leg.br/api/v2/deputados/178964	Heitor Schuch	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	RS	57	https://www.camara.leg.br/internet/deputado/bandep/178964.jpg	dep.heitorschuch@camara.leg.br
329	178873	https://dadosabertos.camara.leg.br/api/v2/deputados/178873	Helder Salomão	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	ES	57	https://www.camara.leg.br/internet/deputado/bandep/178873.jpg	dep.heldersalomao@camara.leg.br
330	220537	https://dadosabertos.camara.leg.br/api/v2/deputados/220537	Helena Lima	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	RR	57	https://www.camara.leg.br/internet/deputado/bandep/220537.jpg	dep.helenalima@camara.leg.br
331	178909	https://dadosabertos.camara.leg.br/api/v2/deputados/178909	Hélio Leite	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PA	57	https://www.camara.leg.br/internet/deputado/bandep/178909.jpg	\N
332	204444	https://dadosabertos.camara.leg.br/api/v2/deputados/204444	Helio Lopes	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204444.jpg	dep.heliolopes@camara.leg.br
333	220672	https://dadosabertos.camara.leg.br/api/v2/deputados/220672	Henderson Pinto	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PA	57	https://www.camara.leg.br/internet/deputado/bandep/220672.jpg	dep.hendersonpinto@camara.leg.br
334	227324	https://dadosabertos.camara.leg.br/api/v2/deputados/227324	Henrique Júnior	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MA	57	https://www.camara.leg.br/internet/deputado/bandep/227324.jpg	\N
335	204539	https://dadosabertos.camara.leg.br/api/v2/deputados/204539	Hercílio Coelho Diniz	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204539.jpg	dep.herciliocoelhodiniz@camara.leg.br
306	74383	https://dadosabertos.camara.leg.br/api/v2/deputados/74383	Giacobo	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PR	57	https://www.camara.leg.br/internet/deputado/bandep/74383.jpg	dep.giacobo@camara.leg.br
307	204491	https://dadosabertos.camara.leg.br/api/v2/deputados/204491	Gilberto Abramo	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204491.jpg	dep.gilbertoabramo@camara.leg.br
342	204508	https://dadosabertos.camara.leg.br/api/v2/deputados/204508	Igor Timo	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204508.jpg	dep.igortimo@camara.leg.br
352	220697	https://dadosabertos.camara.leg.br/api/v2/deputados/220697	Jadyel Alencar	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	PI	57	https://www.camara.leg.br/internet/deputado/bandep/220697.jpg	dep.jadyelalencar@camara.leg.br
363	141459	https://dadosabertos.camara.leg.br/api/v2/deputados/141459	João Maia	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	RN	57	https://www.camara.leg.br/internet/deputado/bandep/141459.jpg	dep.joaomaia@camara.leg.br
338	141450	https://dadosabertos.camara.leg.br/api/v2/deputados/141450	Hugo Leal	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/141450.jpg	dep.hugoleal@camara.leg.br
339	160674	https://dadosabertos.camara.leg.br/api/v2/deputados/160674	Hugo Motta	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	PB	57	https://www.camara.leg.br/internet/deputado/bandep/160674.jpg	dep.hugomotta@camara.leg.br
340	220563	https://dadosabertos.camara.leg.br/api/v2/deputados/220563	Icaro de Valmir	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SE	57	https://www.camara.leg.br/internet/deputado/bandep/220563.jpg	dep.icarodevalmir@camara.leg.br
341	204533	https://dadosabertos.camara.leg.br/api/v2/deputados/204533	Idilvan Alencar	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	CE	57	https://www.camara.leg.br/internet/deputado/bandep/204533.jpg	\N
344	98615	https://dadosabertos.camara.leg.br/api/v2/deputados/98615	Ismael	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SC	57	https://www.camara.leg.br/internet/deputado/bandep/98615.jpg	dep.ismael@camara.leg.br
346	204436	https://dadosabertos.camara.leg.br/api/v2/deputados/204436	Isnaldo Bulhões Jr.	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	AL	57	https://www.camara.leg.br/internet/deputado/bandep/204436.jpg	dep.isnaldobulhoesjr@camara.leg.br
347	230764	https://dadosabertos.camara.leg.br/api/v2/deputados/230764	Ivan Junior	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	MA	57	https://www.camara.leg.br/internet/deputado/bandep/230764.jpg	\N
348	73531	https://dadosabertos.camara.leg.br/api/v2/deputados/73531	Ivan Valente	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	SP	57	https://www.camara.leg.br/internet/deputado/bandep/73531.jpg	dep.ivanvalente@camara.leg.br
349	220696	https://dadosabertos.camara.leg.br/api/v2/deputados/220696	Ivoneide Caetano	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	BA	57	https://www.camara.leg.br/internet/deputado/bandep/220696.jpg	dep.ivoneidecaetano@camara.leg.br
350	220670	https://dadosabertos.camara.leg.br/api/v2/deputados/220670	Iza Arruda	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PE	57	https://www.camara.leg.br/internet/deputado/bandep/220670.jpg	dep.izaarruda@camara.leg.br
351	220527	https://dadosabertos.camara.leg.br/api/v2/deputados/220527	Jack Rocha	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	ES	57	https://www.camara.leg.br/internet/deputado/bandep/220527.jpg	dep.jackrocha@camara.leg.br
354	74848	https://dadosabertos.camara.leg.br/api/v2/deputados/74848	Jandira Feghali	PCdoB	https://dadosabertos.camara.leg.br/api/v2/partidos/36779	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/74848.jpg	dep.jandirafeghali@camara.leg.br
355	220567	https://dadosabertos.camara.leg.br/api/v2/deputados/220567	Jeferson Rodrigues	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	GO	57	https://www.camara.leg.br/internet/deputado/bandep/220567.jpg	dep.jefersonrodrigues@camara.leg.br
356	74273	https://dadosabertos.camara.leg.br/api/v2/deputados/74273	Jefferson Campos	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/74273.jpg	dep.jeffersoncampos@camara.leg.br
357	160531	https://dadosabertos.camara.leg.br/api/v2/deputados/160531	Jhonatan de Jesus	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RR	57	https://www.camara.leg.br/internet/deputado/bandep/160531.jpg	\N
358	141456	https://dadosabertos.camara.leg.br/api/v2/deputados/141456	Jilmar Tatto	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/141456.jpg	dep.jilmartatto@camara.leg.br
359	141458	https://dadosabertos.camara.leg.br/api/v2/deputados/141458	João Carlos Bacelar	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	BA	57	https://www.camara.leg.br/internet/deputado/bandep/141458.jpg	dep.joaocarlosbacelar@camara.leg.br
360	230957	https://dadosabertos.camara.leg.br/api/v2/deputados/230957	João Cury	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	SP	57	https://www.camara.leg.br/internet/deputado/bandep/230957.jpg	dep.joaocury@camara.leg.br
361	178970	https://dadosabertos.camara.leg.br/api/v2/deputados/178970	João Daniel	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SE	57	https://www.camara.leg.br/internet/deputado/bandep/178970.jpg	dep.joaodaniel@camara.leg.br
362	74550	https://dadosabertos.camara.leg.br/api/v2/deputados/74550	João Leão	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	BA	57	https://www.camara.leg.br/internet/deputado/bandep/74550.jpg	dep.joaoleao@camara.leg.br
365	178910	https://dadosabertos.camara.leg.br/api/v2/deputados/178910	Joaquim Passarinho	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PA	57	https://www.camara.leg.br/internet/deputado/bandep/178910.jpg	dep.joaquimpassarinho@camara.leg.br
366	160548	https://dadosabertos.camara.leg.br/api/v2/deputados/160548	Jonas Donizette	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	SP	57	https://www.camara.leg.br/internet/deputado/bandep/160548.jpg	dep.jonasdonizette@camara.leg.br
336	100689	https://dadosabertos.camara.leg.br/api/v2/deputados/100689	Hildo do Candango	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	GO	57	https://www.camara.leg.br/internet/deputado/bandep/100689.jpg	\N
337	178884	https://dadosabertos.camara.leg.br/api/v2/deputados/178884	Hildo Rocha	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	MA	57	https://www.camara.leg.br/internet/deputado/bandep/178884.jpg	dep.hildorocha@camara.leg.br
369	214694	https://dadosabertos.camara.leg.br/api/v2/deputados/214694	Jorge Goetten	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	SC	57	https://www.camara.leg.br/internet/deputado/bandep/214694.jpg	dep.jorgegoetten@camara.leg.br
375	204391	https://dadosabertos.camara.leg.br/api/v2/deputados/204391	José Nelto	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	GO	57	https://www.camara.leg.br/internet/deputado/bandep/204391.jpg	dep.josenelto@camara.leg.br
371	178857	https://dadosabertos.camara.leg.br/api/v2/deputados/178857	Jorge Solla	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	BA	57	https://www.camara.leg.br/internet/deputado/bandep/178857.jpg	dep.jorgesolla@camara.leg.br
372	141464	https://dadosabertos.camara.leg.br/api/v2/deputados/141464	José Airton Félix Cirilo	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	CE	57	https://www.camara.leg.br/internet/deputado/bandep/141464.jpg	dep.joseairtonfelixcirilo@camara.leg.br
373	141470	https://dadosabertos.camara.leg.br/api/v2/deputados/141470	José Guimarães	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	CE	57	https://www.camara.leg.br/internet/deputado/bandep/141470.jpg	dep.joseguimaraes@camara.leg.br
374	204472	https://dadosabertos.camara.leg.br/api/v2/deputados/204472	José Medeiros	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MT	57	https://www.camara.leg.br/internet/deputado/bandep/204472.jpg	dep.josemedeiros@camara.leg.br
377	74079	https://dadosabertos.camara.leg.br/api/v2/deputados/74079	José Priante	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PA	57	https://www.camara.leg.br/internet/deputado/bandep/74079.jpg	dep.josepriante@camara.leg.br
378	74554	https://dadosabertos.camara.leg.br/api/v2/deputados/74554	José Rocha	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	BA	57	https://www.camara.leg.br/internet/deputado/bandep/74554.jpg	dep.joserocha@camara.leg.br
379	209189	https://dadosabertos.camara.leg.br/api/v2/deputados/209189	Joseildo Ramos	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	BA	57	https://www.camara.leg.br/internet/deputado/bandep/209189.jpg	dep.joseildoramos@camara.leg.br
380	220578	https://dadosabertos.camara.leg.br/api/v2/deputados/220578	Josenildo	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	AP	57	https://www.camara.leg.br/internet/deputado/bandep/220578.jpg	dep.josenildo@camara.leg.br
381	74141	https://dadosabertos.camara.leg.br/api/v2/deputados/74141	Josias Gomes	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	BA	57	https://www.camara.leg.br/internet/deputado/bandep/74141.jpg	dep.josiasgomes@camara.leg.br
382	204563	https://dadosabertos.camara.leg.br/api/v2/deputados/204563	Josimar Maranhãozinho	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MA	57	https://www.camara.leg.br/internet/deputado/bandep/204563.jpg	dep.josimarmaranhaozinho@camara.leg.br
383	215043	https://dadosabertos.camara.leg.br/api/v2/deputados/215043	Josivaldo JP	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	MA	57	https://www.camara.leg.br/internet/deputado/bandep/215043.jpg	dep.josivaldojp@camara.leg.br
384	204474	https://dadosabertos.camara.leg.br/api/v2/deputados/204474	Juarez Costa	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	MT	57	https://www.camara.leg.br/internet/deputado/bandep/204474.jpg	dep.juarezcosta@camara.leg.br
385	220559	https://dadosabertos.camara.leg.br/api/v2/deputados/220559	Julia Zanatta	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SC	57	https://www.camara.leg.br/internet/deputado/bandep/220559.jpg	dep.juliazanatta@camara.leg.br
386	220640	https://dadosabertos.camara.leg.br/api/v2/deputados/220640	Juliana Cardoso	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220640.jpg	dep.julianacardoso@camara.leg.br
387	228837	https://dadosabertos.camara.leg.br/api/v2/deputados/228837	Juliana Kolankiewicz	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	MT	57	https://www.camara.leg.br/internet/deputado/bandep/228837.jpg	\N
388	66385	https://dadosabertos.camara.leg.br/api/v2/deputados/66385	Julio Arcoverde	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PI	57	https://www.camara.leg.br/internet/deputado/bandep/66385.jpg	dep.julioarcoverde@camara.leg.br
389	74317	https://dadosabertos.camara.leg.br/api/v2/deputados/74317	Júlio Cesar	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PI	57	https://www.camara.leg.br/internet/deputado/bandep/74317.jpg	dep.juliocesar@camara.leg.br
390	204372	https://dadosabertos.camara.leg.br/api/v2/deputados/204372	Julio Cesar Ribeiro	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	DF	57	https://www.camara.leg.br/internet/deputado/bandep/204372.jpg	dep.juliocesarribeiro@camara.leg.br
391	74253	https://dadosabertos.camara.leg.br/api/v2/deputados/74253	Julio Lopes	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/74253.jpg	dep.juliolopes@camara.leg.br
392	228797	https://dadosabertos.camara.leg.br/api/v2/deputados/228797	Júlio Oliveira	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	TO	57	https://www.camara.leg.br/internet/deputado/bandep/228797.jpg	\N
393	204457	https://dadosabertos.camara.leg.br/api/v2/deputados/204457	Juninho do Pneu	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204457.jpg	dep.juninhodopneu@camara.leg.br
394	204520	https://dadosabertos.camara.leg.br/api/v2/deputados/204520	Junio Amaral	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204520.jpg	dep.junioamaral@camara.leg.br
395	204497	https://dadosabertos.camara.leg.br/api/v2/deputados/204497	Júnior Ferrari	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PA	57	https://www.camara.leg.br/internet/deputado/bandep/204497.jpg	dep.juniorferrari@camara.leg.br
396	204574	https://dadosabertos.camara.leg.br/api/v2/deputados/204574	Junior Lourenço	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MA	57	https://www.camara.leg.br/internet/deputado/bandep/204574.jpg	dep.juniorlourenco@camara.leg.br
367	217480	https://dadosabertos.camara.leg.br/api/v2/deputados/217480	Jones Moura	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/217480.jpg	\N
368	205550	https://dadosabertos.camara.leg.br/api/v2/deputados/205550	Jorge Braz	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/205550.jpg	dep.jorgebraz@camara.leg.br
397	204550	https://dadosabertos.camara.leg.br/api/v2/deputados/204550	Júnior Mano	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	CE	57	https://www.camara.leg.br/internet/deputado/bandep/204550.jpg	dep.juniormano@camara.leg.br
426	220581	https://dadosabertos.camara.leg.br/api/v2/deputados/220581	Luciano Amaral	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	AL	57	https://www.camara.leg.br/internet/deputado/bandep/220581.jpg	dep.lucianoamaral@camara.leg.br
406	98057	https://dadosabertos.camara.leg.br/api/v2/deputados/98057	Lafayette de Andrada	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	MG	57	https://www.camara.leg.br/internet/deputado/bandep/98057.jpg	dep.lafayettedeandrada@camara.leg.br
414	122195	https://dadosabertos.camara.leg.br/api/v2/deputados/122195	Leonardo Gadelha	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	PB	57	https://www.camara.leg.br/internet/deputado/bandep/122195.jpg	\N
403	220677	https://dadosabertos.camara.leg.br/api/v2/deputados/220677	Keniston Braga	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PA	57	https://www.camara.leg.br/internet/deputado/bandep/220677.jpg	dep.kenistonbraga@camara.leg.br
404	162067	https://dadosabertos.camara.leg.br/api/v2/deputados/162067	Kiko Celeguim	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/162067.jpg	dep.kikoceleguim@camara.leg.br
407	74856	https://dadosabertos.camara.leg.br/api/v2/deputados/74856	Laura Carneiro	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/74856.jpg	dep.lauracarneiro@camara.leg.br
408	141480	https://dadosabertos.camara.leg.br/api/v2/deputados/141480	Lázaro Botelho	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	TO	57	https://www.camara.leg.br/internet/deputado/bandep/141480.jpg	\N
409	178832	https://dadosabertos.camara.leg.br/api/v2/deputados/178832	Leandre	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PR	57	https://www.camara.leg.br/internet/deputado/bandep/178832.jpg	\N
410	220600	https://dadosabertos.camara.leg.br/api/v2/deputados/220600	Lebrão	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RO	57	https://www.camara.leg.br/internet/deputado/bandep/220600.jpg	\N
411	220566	https://dadosabertos.camara.leg.br/api/v2/deputados/220566	Lêda Borges	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	GO	57	https://www.camara.leg.br/internet/deputado/bandep/220566.jpg	dep.ledaborges@camara.leg.br
412	231911	https://dadosabertos.camara.leg.br/api/v2/deputados/231911	Lenir de Assis	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PR	57	https://www.camara.leg.br/internet/deputado/bandep/231911.jpg	dep.lenirdeassis@camara.leg.br
413	80815	https://dadosabertos.camara.leg.br/api/v2/deputados/80815	Leo Prates	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	BA	57	https://www.camara.leg.br/internet/deputado/bandep/80815.jpg	dep.leoprates@camara.leg.br
416	74156	https://dadosabertos.camara.leg.br/api/v2/deputados/74156	Leonardo Monteiro	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MG	57	https://www.camara.leg.br/internet/deputado/bandep/74156.jpg	dep.leonardomonteiro@camara.leg.br
417	74299	https://dadosabertos.camara.leg.br/api/v2/deputados/74299	Leônidas Cristino	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	CE	57	https://www.camara.leg.br/internet/deputado/bandep/74299.jpg	dep.leonidascristino@camara.leg.br
418	92102	https://dadosabertos.camara.leg.br/api/v2/deputados/92102	Leur Lomanto Júnior	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	BA	57	https://www.camara.leg.br/internet/deputado/bandep/92102.jpg	dep.leurlomantojunior@camara.leg.br
419	139285	https://dadosabertos.camara.leg.br/api/v2/deputados/139285	Lídice da Mata	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	BA	57	https://www.camara.leg.br/internet/deputado/bandep/139285.jpg	dep.lidicedamata@camara.leg.br
420	74585	https://dadosabertos.camara.leg.br/api/v2/deputados/74585	Lincoln Portela	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/74585.jpg	dep.lincolnportela@camara.leg.br
421	74858	https://dadosabertos.camara.leg.br/api/v2/deputados/74858	Lindbergh Farias	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/74858.jpg	dep.lindberghfarias@camara.leg.br
422	171139	https://dadosabertos.camara.leg.br/api/v2/deputados/171139	Loreny	SOLIDARIEDADE	https://dadosabertos.camara.leg.br/api/v2/partidos/37904	SP	57	https://www.camara.leg.br/internet/deputado/bandep/171139.jpg	\N
423	220662	https://dadosabertos.camara.leg.br/api/v2/deputados/220662	Lucas Ramos	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	PE	57	https://www.camara.leg.br/internet/deputado/bandep/220662.jpg	dep.lucasramos@camara.leg.br
424	204404	https://dadosabertos.camara.leg.br/api/v2/deputados/204404	Lucas Redecker	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	RS	57	https://www.camara.leg.br/internet/deputado/bandep/204404.jpg	dep.lucasredecker@camara.leg.br
425	138286	https://dadosabertos.camara.leg.br/api/v2/deputados/138286	Luciano Alves	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PR	57	https://www.camara.leg.br/internet/deputado/bandep/138286.jpg	dep.lucianoalves@camara.leg.br
428	103758	https://dadosabertos.camara.leg.br/api/v2/deputados/103758	Luciano Azevedo	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RS	57	https://www.camara.leg.br/internet/deputado/bandep/103758.jpg	\N
429	74478	https://dadosabertos.camara.leg.br/api/v2/deputados/74478	Luciano Bivar	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PE	57	https://www.camara.leg.br/internet/deputado/bandep/74478.jpg	dep.lucianobivar@camara.leg.br
430	178931	https://dadosabertos.camara.leg.br/api/v2/deputados/178931	Luciano Ducci	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	PR	57	https://www.camara.leg.br/internet/deputado/bandep/178931.jpg	dep.lucianoducci@camara.leg.br
399	178886	https://dadosabertos.camara.leg.br/api/v2/deputados/178886	Juscelino Filho	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	MA	57	https://www.camara.leg.br/internet/deputado/bandep/178886.jpg	dep.juscelinofilho@camara.leg.br
400	208297	https://dadosabertos.camara.leg.br/api/v2/deputados/208297	Katia Dias	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	MG	57	https://www.camara.leg.br/internet/deputado/bandep/208297.jpg	\N
435	229082	https://dadosabertos.camara.leg.br/api/v2/deputados/229082	Lucyana Genésio	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	MA	57	https://www.camara.leg.br/internet/deputado/bandep/229082.jpg	\N
451	204526	https://dadosabertos.camara.leg.br/api/v2/deputados/204526	Luiz Philippe de Orleans e Bragança	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204526.jpg	dep.luizphilippedeorleansebraganca@camara.leg.br
437	160510	https://dadosabertos.camara.leg.br/api/v2/deputados/160510	Luis Tibé	AVANTE	https://dadosabertos.camara.leg.br/api/v2/partidos/36898	MG	57	https://www.camara.leg.br/internet/deputado/bandep/160510.jpg	dep.luistibe@camara.leg.br
459	156190	https://dadosabertos.camara.leg.br/api/v2/deputados/156190	Marcel van Hattem	NOVO	https://dadosabertos.camara.leg.br/api/v2/partidos/37901	RS	57	https://www.camara.leg.br/internet/deputado/bandep/156190.jpg	dep.marcelvanhattem@camara.leg.br
438	204410	https://dadosabertos.camara.leg.br/api/v2/deputados/204410	Luisa Canziani	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PR	57	https://www.camara.leg.br/internet/deputado/bandep/204410.jpg	dep.luisacanziani@camara.leg.br
439	204448	https://dadosabertos.camara.leg.br/api/v2/deputados/204448	Luiz Antonio Corrêa	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204448.jpg	dep.luizantoniocorrea@camara.leg.br
440	141485	https://dadosabertos.camara.leg.br/api/v2/deputados/141485	Luiz Carlos Busato	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RS	57	https://www.camara.leg.br/internet/deputado/bandep/141485.jpg	dep.luizcarlosbusato@camara.leg.br
441	73778	https://dadosabertos.camara.leg.br/api/v2/deputados/73778	Luiz Carlos Hauly	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	PR	57	https://www.camara.leg.br/internet/deputado/bandep/73778.jpg	dep.luizcarloshauly@camara.leg.br
442	204485	https://dadosabertos.camara.leg.br/api/v2/deputados/204485	Luiz Carlos Motta	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204485.jpg	dep.luizcarlosmotta@camara.leg.br
443	74041	https://dadosabertos.camara.leg.br/api/v2/deputados/74041	Luiz Couto	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PB	57	https://www.camara.leg.br/internet/deputado/bandep/74041.jpg	dep.luizcouto@camara.leg.br
444	141487	https://dadosabertos.camara.leg.br/api/v2/deputados/141487	Luiz Fernando Faria	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	MG	57	https://www.camara.leg.br/internet/deputado/bandep/141487.jpg	dep.luizfernandofaria@camara.leg.br
445	229432	https://dadosabertos.camara.leg.br/api/v2/deputados/229432	Luiz Fernando Vampiro	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	SC	57	https://www.camara.leg.br/internet/deputado/bandep/229432.jpg	dep.luizfernandovampiro@camara.leg.br
446	220658	https://dadosabertos.camara.leg.br/api/v2/deputados/220658	Luiz Gastão	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	CE	57	https://www.camara.leg.br/internet/deputado/bandep/220658.jpg	dep.luizgastao@camara.leg.br
449	220636	https://dadosabertos.camara.leg.br/api/v2/deputados/220636	Luiz Marinho	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220636.jpg	\N
447	204455	https://dadosabertos.camara.leg.br/api/v2/deputados/204455	Luiz Lima	NOVO	https://dadosabertos.camara.leg.br/api/v2/partidos/37901	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204455.jpg	dep.luizlima@camara.leg.br
453	178866	https://dadosabertos.camara.leg.br/api/v2/deputados/178866	Luizianne Lins	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	CE	57	https://www.camara.leg.br/internet/deputado/bandep/178866.jpg	dep.luiziannelins@camara.leg.br
450	162332	https://dadosabertos.camara.leg.br/api/v2/deputados/162332	Luiz Nishimori	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PR	57	https://www.camara.leg.br/internet/deputado/bandep/162332.jpg	dep.luiznishimori@camara.leg.br
454	220669	https://dadosabertos.camara.leg.br/api/v2/deputados/220669	Lula da Fonte	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PE	57	https://www.camara.leg.br/internet/deputado/bandep/220669.jpg	dep.luladafonte@camara.leg.br
452	74784	https://dadosabertos.camara.leg.br/api/v2/deputados/74784	Luiza Erundina	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	SP	57	https://www.camara.leg.br/internet/deputado/bandep/74784.jpg	dep.luizaerundina@camara.leg.br
455	166402	https://dadosabertos.camara.leg.br/api/v2/deputados/166402	Magda Mofatto	PRD	https://dadosabertos.camara.leg.br/api/v2/partidos/38010	GO	57	https://www.camara.leg.br/internet/deputado/bandep/166402.jpg	dep.magdamofatto@camara.leg.br
458	220648	https://dadosabertos.camara.leg.br/api/v2/deputados/220648	Marangoni	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220648.jpg	dep.marangoni@camara.leg.br
431	227323	https://dadosabertos.camara.leg.br/api/v2/deputados/227323	Luciano Galego	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MA	57	https://www.camara.leg.br/internet/deputado/bandep/227323.jpg	\N
436	222429	https://dadosabertos.camara.leg.br/api/v2/deputados/222429	Luis Carlos Gomes	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/222429.jpg	dep.luiscarlosgomes@camara.leg.br
432	220616	https://dadosabertos.camara.leg.br/api/v2/deputados/220616	Luciano Vieira	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220616.jpg	dep.lucianovieira@camara.leg.br
434	178954	https://dadosabertos.camara.leg.br/api/v2/deputados/178954	Lucio Mosquini	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	RO	57	https://www.camara.leg.br/internet/deputado/bandep/178954.jpg	dep.luciomosquini@camara.leg.br
491	74158	https://dadosabertos.camara.leg.br/api/v2/deputados/74158	Mário Heringer	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	MG	57	https://www.camara.leg.br/internet/deputado/bandep/74158.jpg	dep.marioheringer@camara.leg.br
470	179001	https://dadosabertos.camara.leg.br/api/v2/deputados/179001	Márcio Biolchi	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	RS	57	https://www.camara.leg.br/internet/deputado/bandep/179001.jpg	dep.marciobiolchi@camara.leg.br
467	160161	https://dadosabertos.camara.leg.br/api/v2/deputados/160161	Marcelo Queiroz	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/160161.jpg	\N
463	220634	https://dadosabertos.camara.leg.br/api/v2/deputados/220634	Marcelo Lima	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220634.jpg	\N
466	133810	https://dadosabertos.camara.leg.br/api/v2/deputados/133810	Marcelo Moraes	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RS	57	https://www.camara.leg.br/internet/deputado/bandep/133810.jpg	dep.marcelomoraes@camara.leg.br
469	178983	https://dadosabertos.camara.leg.br/api/v2/deputados/178983	Marcio Alvino	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/178983.jpg	dep.marcioalvino@camara.leg.br
471	226410	https://dadosabertos.camara.leg.br/api/v2/deputados/226410	Márcio Correa	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	GO	57	https://www.camara.leg.br/internet/deputado/bandep/226410.jpg	\N
472	220687	https://dadosabertos.camara.leg.br/api/v2/deputados/220687	Márcio Honaiser	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	MA	57	https://www.camara.leg.br/internet/deputado/bandep/220687.jpg	dep.marciohonaiser@camara.leg.br
473	81055	https://dadosabertos.camara.leg.br/api/v2/deputados/81055	Márcio Jerry	PCdoB	https://dadosabertos.camara.leg.br/api/v2/partidos/36779	MA	57	https://www.camara.leg.br/internet/deputado/bandep/81055.jpg	dep.marciojerry@camara.leg.br
474	150418	https://dadosabertos.camara.leg.br/api/v2/deputados/150418	Márcio Marinho	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	BA	57	https://www.camara.leg.br/internet/deputado/bandep/150418.jpg	dep.marciomarinho@camara.leg.br
475	204522	https://dadosabertos.camara.leg.br/api/v2/deputados/204522	Marco Bertaiolli	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204522.jpg	\N
476	219585	https://dadosabertos.camara.leg.br/api/v2/deputados/219585	Marco Brasil	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PR	57	https://www.camara.leg.br/internet/deputado/bandep/219585.jpg	\N
477	160535	https://dadosabertos.camara.leg.br/api/v2/deputados/160535	Marcon	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RS	57	https://www.camara.leg.br/internet/deputado/bandep/160535.jpg	dep.marcon@camara.leg.br
478	204431	https://dadosabertos.camara.leg.br/api/v2/deputados/204431	Marcos Aurélio Sampaio	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PI	57	https://www.camara.leg.br/internet/deputado/bandep/204431.jpg	dep.marcosaureliosampaio@camara.leg.br
479	204506	https://dadosabertos.camara.leg.br/api/v2/deputados/204506	Marcos Pereira	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204506.jpg	dep.marcospereira@camara.leg.br
480	220547	https://dadosabertos.camara.leg.br/api/v2/deputados/220547	Marcos Pollon	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MS	57	https://www.camara.leg.br/internet/deputado/bandep/220547.jpg	dep.marcospollon@camara.leg.br
481	178943	https://dadosabertos.camara.leg.br/api/v2/deputados/178943	Marcos Soares	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/178943.jpg	dep.marcossoares@camara.leg.br
482	220604	https://dadosabertos.camara.leg.br/api/v2/deputados/220604	Marcos Tavares	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220604.jpg	dep.marcostavares@camara.leg.br
483	220668	https://dadosabertos.camara.leg.br/api/v2/deputados/220668	Maria Arraes	SOLIDARIEDADE	https://dadosabertos.camara.leg.br/api/v2/partidos/37904	PE	57	https://www.camara.leg.br/internet/deputado/bandep/220668.jpg	dep.mariaarraes@camara.leg.br
484	74398	https://dadosabertos.camara.leg.br/api/v2/deputados/74398	Maria do Rosário	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RS	57	https://www.camara.leg.br/internet/deputado/bandep/74398.jpg	dep.mariadorosario@camara.leg.br
485	204540	https://dadosabertos.camara.leg.br/api/v2/deputados/204540	Maria Rosas	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204540.jpg	dep.mariarosas@camara.leg.br
486	227275	https://dadosabertos.camara.leg.br/api/v2/deputados/227275	Mariana Carvalho	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	MA	57	https://www.camara.leg.br/internet/deputado/bandep/227275.jpg	\N
489	220637	https://dadosabertos.camara.leg.br/api/v2/deputados/220637	Marina Silva	REDE	https://dadosabertos.camara.leg.br/api/v2/partidos/36886	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220637.jpg	\N
490	220655	https://dadosabertos.camara.leg.br/api/v2/deputados/220655	Mario Frias	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220655.jpg	dep.mariofrias@camara.leg.br
492	178858	https://dadosabertos.camara.leg.br/api/v2/deputados/178858	Mário Negromonte Jr.	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	BA	57	https://www.camara.leg.br/internet/deputado/bandep/178858.jpg	dep.marionegromontejr@camara.leg.br
551	171617	https://dadosabertos.camara.leg.br/api/v2/deputados/171617	Paulão	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	AL	57	https://www.camara.leg.br/internet/deputado/bandep/171617.jpg	dep.paulao@camara.leg.br
461	204433	https://dadosabertos.camara.leg.br/api/v2/deputados/204433	Marcelo Calero	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204433.jpg	\N
462	220599	https://dadosabertos.camara.leg.br/api/v2/deputados/220599	Marcelo Crivella	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220599.jpg	dep.marcelocrivella@camara.leg.br
493	204566	https://dadosabertos.camara.leg.br/api/v2/deputados/204566	Marreca Filho	PRD	https://dadosabertos.camara.leg.br/api/v2/partidos/38010	MA	57	https://www.camara.leg.br/internet/deputado/bandep/204566.jpg	dep.marrecafilho@camara.leg.br
497	220661	https://dadosabertos.camara.leg.br/api/v2/deputados/220661	Matheus Noronha	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	CE	57	https://www.camara.leg.br/internet/deputado/bandep/220661.jpg	dep.matheusnoronha@camara.leg.br
508	188097	https://dadosabertos.camara.leg.br/api/v2/deputados/188097	Merlong Solano	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PI	57	https://www.camara.leg.br/internet/deputado/bandep/188097.jpg	dep.merlongsolano@camara.leg.br
498	220609	https://dadosabertos.camara.leg.br/api/v2/deputados/220609	Maurício Carvalho	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RO	57	https://www.camara.leg.br/internet/deputado/bandep/220609.jpg	dep.mauriciocarvalho@camara.leg.br
499	220628	https://dadosabertos.camara.leg.br/api/v2/deputados/220628	Mauricio do Vôlei	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/220628.jpg	dep.mauriciodovolei@camara.leg.br
500	220550	https://dadosabertos.camara.leg.br/api/v2/deputados/220550	Mauricio Marcon	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	RS	57	https://www.camara.leg.br/internet/deputado/bandep/220550.jpg	dep.mauriciomarcon@camara.leg.br
501	220647	https://dadosabertos.camara.leg.br/api/v2/deputados/220647	Mauricio Neves	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220647.jpg	dep.mauricioneves@camara.leg.br
502	204486	https://dadosabertos.camara.leg.br/api/v2/deputados/204486	Mauro Benevides Filho	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	CE	57	https://www.camara.leg.br/internet/deputado/bandep/204486.jpg	dep.maurobenevidesfilho@camara.leg.br
503	220607	https://dadosabertos.camara.leg.br/api/v2/deputados/220607	Max Lemos	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220607.jpg	dep.maxlemos@camara.leg.br
506	220591	https://dadosabertos.camara.leg.br/api/v2/deputados/220591	Meire Serafim	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	AC	57	https://www.camara.leg.br/internet/deputado/bandep/220591.jpg	dep.meireserafim@camara.leg.br
507	74428	https://dadosabertos.camara.leg.br/api/v2/deputados/74428	Mendonça Filho	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PE	57	https://www.camara.leg.br/internet/deputado/bandep/74428.jpg	dep.mendoncafilho@camara.leg.br
509	220585	https://dadosabertos.camara.leg.br/api/v2/deputados/220585	Mersinho Lucena	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PB	57	https://www.camara.leg.br/internet/deputado/bandep/220585.jpg	dep.mersinholucena@camara.leg.br
510	220530	https://dadosabertos.camara.leg.br/api/v2/deputados/220530	Messias Donato	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	ES	57	https://www.camara.leg.br/internet/deputado/bandep/220530.jpg	dep.messiasdonato@camara.leg.br
511	171786	https://dadosabertos.camara.leg.br/api/v2/deputados/171786	Miguel Ângelo	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MG	57	https://www.camara.leg.br/internet/deputado/bandep/171786.jpg	dep.miguelangelo@camara.leg.br
512	178985	https://dadosabertos.camara.leg.br/api/v2/deputados/178985	Miguel Lombardi	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/178985.jpg	dep.miguellombardi@camara.leg.br
513	154178	https://dadosabertos.camara.leg.br/api/v2/deputados/154178	Milton Vieira	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	SP	57	https://www.camara.leg.br/internet/deputado/bandep/154178.jpg	\N
514	178895	https://dadosabertos.camara.leg.br/api/v2/deputados/178895	Misael Varella	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	MG	57	https://www.camara.leg.br/internet/deputado/bandep/178895.jpg	dep.misaelvarella@camara.leg.br
515	229225	https://dadosabertos.camara.leg.br/api/v2/deputados/229225	Missionária Michele Collins	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PE	57	https://www.camara.leg.br/internet/deputado/bandep/229225.jpg	\N
516	160561	https://dadosabertos.camara.leg.br/api/v2/deputados/160561	Missionário José Olimpio	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/160561.jpg	dep.missionariojoseolimpio@camara.leg.br
517	178997	https://dadosabertos.camara.leg.br/api/v2/deputados/178997	Moses Rodrigues	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	CE	57	https://www.camara.leg.br/internet/deputado/bandep/178997.jpg	dep.mosesrodrigues@camara.leg.br
518	220617	https://dadosabertos.camara.leg.br/api/v2/deputados/220617	Murillo Gouvea	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220617.jpg	dep.murillogouvea@camara.leg.br
519	220584	https://dadosabertos.camara.leg.br/api/v2/deputados/220584	Murilo Galdino	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	PB	57	https://www.camara.leg.br/internet/deputado/bandep/220584.jpg	dep.murilogaldino@camara.leg.br
520	204453	https://dadosabertos.camara.leg.br/api/v2/deputados/204453	Natália Bonavides	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RN	57	https://www.camara.leg.br/internet/deputado/bandep/204453.jpg	dep.nataliabonavides@camara.leg.br
521	228042	https://dadosabertos.camara.leg.br/api/v2/deputados/228042	Naumi Amorim	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	CE	57	https://www.camara.leg.br/internet/deputado/bandep/228042.jpg	\N
495	220572	https://dadosabertos.camara.leg.br/api/v2/deputados/220572	Marussa Boldrin	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	GO	57	https://www.camara.leg.br/internet/deputado/bandep/220572.jpg	dep.marussaboldrin@camara.leg.br
496	178843	https://dadosabertos.camara.leg.br/api/v2/deputados/178843	Marx Beltrão	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	AL	57	https://www.camara.leg.br/internet/deputado/bandep/178843.jpg	dep.marxbeltrao@camara.leg.br
525	220703	https://dadosabertos.camara.leg.br/api/v2/deputados/220703	Neto Carletto	AVANTE	https://dadosabertos.camara.leg.br/api/v2/partidos/36898	BA	57	https://www.camara.leg.br/internet/deputado/bandep/220703.jpg	dep.netocarletto@camara.leg.br
536	73692	https://dadosabertos.camara.leg.br/api/v2/deputados/73692	Osmar Terra	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RS	57	https://www.camara.leg.br/internet/deputado/bandep/73692.jpg	dep.osmarterra@camara.leg.br
524	220622	https://dadosabertos.camara.leg.br/api/v2/deputados/220622	Nely Aquino	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	MG	57	https://www.camara.leg.br/internet/deputado/bandep/220622.jpg	dep.nelyaquino@camara.leg.br
527	229939	https://dadosabertos.camara.leg.br/api/v2/deputados/229939	Newton Bonin	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PR	57	https://www.camara.leg.br/internet/deputado/bandep/229939.jpg	\N
528	178896	https://dadosabertos.camara.leg.br/api/v2/deputados/178896	Newton Cardoso Jr	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	MG	57	https://www.camara.leg.br/internet/deputado/bandep/178896.jpg	dep.newtoncardosojr@camara.leg.br
529	204479	https://dadosabertos.camara.leg.br/api/v2/deputados/204479	Nicoletti	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RR	57	https://www.camara.leg.br/internet/deputado/bandep/204479.jpg	dep.nicoletti@camara.leg.br
530	209787	https://dadosabertos.camara.leg.br/api/v2/deputados/209787	Nikolas Ferreira	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/209787.jpg	dep.nikolasferreira@camara.leg.br
531	178986	https://dadosabertos.camara.leg.br/api/v2/deputados/178986	Nilto Tatto	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/178986.jpg	dep.niltotatto@camara.leg.br
532	227660	https://dadosabertos.camara.leg.br/api/v2/deputados/227660	Nitinho	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SE	57	https://www.camara.leg.br/internet/deputado/bandep/227660.jpg	\N
533	74159	https://dadosabertos.camara.leg.br/api/v2/deputados/74159	Odair Cunha	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MG	57	https://www.camara.leg.br/internet/deputado/bandep/74159.jpg	dep.odaircunha@camara.leg.br
534	204498	https://dadosabertos.camara.leg.br/api/v2/deputados/204498	Olival Marques	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PA	57	https://www.camara.leg.br/internet/deputado/bandep/204498.jpg	dep.olivalmarques@camara.leg.br
535	178987	https://dadosabertos.camara.leg.br/api/v2/deputados/178987	Orlando Silva	PCdoB	https://dadosabertos.camara.leg.br/api/v2/partidos/36779	SP	57	https://www.camara.leg.br/internet/deputado/bandep/178987.jpg	dep.orlandosilva@camara.leg.br
538	204422	https://dadosabertos.camara.leg.br/api/v2/deputados/204422	Ossesio Silva	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	PE	57	https://www.camara.leg.br/internet/deputado/bandep/204422.jpg	dep.ossesiosilva@camara.leg.br
539	204441	https://dadosabertos.camara.leg.br/api/v2/deputados/204441	Otoni de Paula	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204441.jpg	dep.otonidepaula@camara.leg.br
540	204573	https://dadosabertos.camara.leg.br/api/v2/deputados/204573	Otto Alencar Filho	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	BA	57	https://www.camara.leg.br/internet/deputado/bandep/204573.jpg	dep.ottoalencarfilho@camara.leg.br
541	220706	https://dadosabertos.camara.leg.br/api/v2/deputados/220706	Padovani	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PR	57	https://www.camara.leg.br/internet/deputado/bandep/220706.jpg	dep.padovani@camara.leg.br
542	160556	https://dadosabertos.camara.leg.br/api/v2/deputados/160556	Padre João	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MG	57	https://www.camara.leg.br/internet/deputado/bandep/160556.jpg	dep.padrejoao@camara.leg.br
543	230762	https://dadosabertos.camara.leg.br/api/v2/deputados/230762	Pastor Claudio Mariano	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	PA	57	https://www.camara.leg.br/internet/deputado/bandep/230762.jpg	dep.pastorclaudiomariano@camara.leg.br
544	180214	https://dadosabertos.camara.leg.br/api/v2/deputados/180214	Pastor Diniz	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RR	57	https://www.camara.leg.br/internet/deputado/bandep/180214.jpg	dep.pastordiniz@camara.leg.br
545	160642	https://dadosabertos.camara.leg.br/api/v2/deputados/160642	Pastor Eurico	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PE	57	https://www.camara.leg.br/internet/deputado/bandep/160642.jpg	dep.pastoreurico@camara.leg.br
546	204570	https://dadosabertos.camara.leg.br/api/v2/deputados/204570	Pastor Gil	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MA	57	https://www.camara.leg.br/internet/deputado/bandep/204570.jpg	dep.pastorgil@camara.leg.br
547	220615	https://dadosabertos.camara.leg.br/api/v2/deputados/220615	Pastor Henrique Vieira	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220615.jpg	dep.pastorhenriquevieira@camara.leg.br
548	204553	https://dadosabertos.camara.leg.br/api/v2/deputados/204553	Pastor Sargento Isidório	AVANTE	https://dadosabertos.camara.leg.br/api/v2/partidos/36898	BA	57	https://www.camara.leg.br/internet/deputado/bandep/204553.jpg	dep.pastorsargentoisidorio@camara.leg.br
549	74160	https://dadosabertos.camara.leg.br/api/v2/deputados/74160	Patrus Ananias	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MG	57	https://www.camara.leg.br/internet/deputado/bandep/74160.jpg	dep.patrusananias@camara.leg.br
550	74095	https://dadosabertos.camara.leg.br/api/v2/deputados/74095	Pauderney Avelino	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	AM	57	https://www.camara.leg.br/internet/deputado/bandep/74095.jpg	dep.pauderneyavelino@camara.leg.br
522	233218	https://dadosabertos.camara.leg.br/api/v2/deputados/233218	Nelinho Freitas	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	CE	57	https://www.camara.leg.br/internet/deputado/bandep/233218.jpg	dep.nelinhofreitas@camara.leg.br
523	204449	https://dadosabertos.camara.leg.br/api/v2/deputados/204449	Nelson Barbudo	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MT	57	https://www.camara.leg.br/internet/deputado/bandep/204449.jpg	dep.nelsonbarbudo@camara.leg.br
557	160517	https://dadosabertos.camara.leg.br/api/v2/deputados/160517	Paulo Folletto	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	ES	57	https://www.camara.leg.br/internet/deputado/bandep/160517.jpg	dep.paulofolletto@camara.leg.br
567	220630	https://dadosabertos.camara.leg.br/api/v2/deputados/220630	Pedro Aihara	PRD	https://dadosabertos.camara.leg.br/api/v2/partidos/38010	MG	57	https://www.camara.leg.br/internet/deputado/bandep/220630.jpg	dep.pedroaihara@camara.leg.br
554	141516	https://dadosabertos.camara.leg.br/api/v2/deputados/141516	Paulo Abi-Ackel	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	MG	57	https://www.camara.leg.br/internet/deputado/bandep/141516.jpg	dep.pauloabiackel@camara.leg.br
555	220650	https://dadosabertos.camara.leg.br/api/v2/deputados/220650	Paulo Alexandre Barbosa	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220650.jpg	dep.pauloalexandrebarbosa@camara.leg.br
556	178860	https://dadosabertos.camara.leg.br/api/v2/deputados/178860	Paulo Azi	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	BA	57	https://www.camara.leg.br/internet/deputado/bandep/178860.jpg	dep.pauloazi@camara.leg.br
559	160558	https://dadosabertos.camara.leg.br/api/v2/deputados/160558	Paulo Freire Costa	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/160558.jpg	dep.paulofreirecosta@camara.leg.br
560	204492	https://dadosabertos.camara.leg.br/api/v2/deputados/204492	Paulo Guedes	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204492.jpg	dep.pauloguedes@camara.leg.br
561	233592	https://dadosabertos.camara.leg.br/api/v2/deputados/233592	Paulo Lemos	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	AP	57	https://www.camara.leg.br/internet/deputado/bandep/233592.jpg	dep.paulolemos@camara.leg.br
562	220685	https://dadosabertos.camara.leg.br/api/v2/deputados/220685	Paulo Litro	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PR	57	https://www.camara.leg.br/internet/deputado/bandep/220685.jpg	dep.paulolitro@camara.leg.br
563	74574	https://dadosabertos.camara.leg.br/api/v2/deputados/74574	Paulo Magalhães	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	BA	57	https://www.camara.leg.br/internet/deputado/bandep/74574.jpg	dep.paulomagalhaes@camara.leg.br
564	128760	https://dadosabertos.camara.leg.br/api/v2/deputados/128760	Paulo Marinho Jr	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MA	57	https://www.camara.leg.br/internet/deputado/bandep/128760.jpg	\N
565	74400	https://dadosabertos.camara.leg.br/api/v2/deputados/74400	Paulo Pimenta	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RS	57	https://www.camara.leg.br/internet/deputado/bandep/74400.jpg	dep.paulopimenta@camara.leg.br
566	141488	https://dadosabertos.camara.leg.br/api/v2/deputados/141488	Paulo Teixeira	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/141488.jpg	\N
569	220667	https://dadosabertos.camara.leg.br/api/v2/deputados/220667	Pedro Campos	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	PE	57	https://www.camara.leg.br/internet/deputado/bandep/220667.jpg	dep.pedrocampos@camara.leg.br
570	229112	https://dadosabertos.camara.leg.br/api/v2/deputados/229112	Pedro Jr	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	TO	57	https://www.camara.leg.br/internet/deputado/bandep/229112.jpg	\N
571	122974	https://dadosabertos.camara.leg.br/api/v2/deputados/122974	Pedro Lucas Fernandes	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	MA	57	https://www.camara.leg.br/internet/deputado/bandep/122974.jpg	dep.pedrolucasfernandes@camara.leg.br
572	204395	https://dadosabertos.camara.leg.br/api/v2/deputados/204395	Pedro Lupion	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PR	57	https://www.camara.leg.br/internet/deputado/bandep/204395.jpg	dep.pedrolupion@camara.leg.br
573	122158	https://dadosabertos.camara.leg.br/api/v2/deputados/122158	Pedro Paulo	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/122158.jpg	dep.pedropaulo@camara.leg.br
574	229259	https://dadosabertos.camara.leg.br/api/v2/deputados/229259	Pedro Tourinho	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/229259.jpg	\N
575	160604	https://dadosabertos.camara.leg.br/api/v2/deputados/160604	Pedro Uczai	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SC	57	https://www.camara.leg.br/internet/deputado/bandep/160604.jpg	dep.pedrouczai@camara.leg.br
576	204406	https://dadosabertos.camara.leg.br/api/v2/deputados/204406	Pedro Westphalen	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	RS	57	https://www.camara.leg.br/internet/deputado/bandep/204406.jpg	dep.pedrowestphalen@camara.leg.br
577	161440	https://dadosabertos.camara.leg.br/api/v2/deputados/161440	Pezenti	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	SC	57	https://www.camara.leg.br/internet/deputado/bandep/161440.jpg	dep.pezenti@camara.leg.br
578	204524	https://dadosabertos.camara.leg.br/api/v2/deputados/204524	Pinheirinho	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204524.jpg	dep.pinheirinho@camara.leg.br
579	73486	https://dadosabertos.camara.leg.br/api/v2/deputados/73486	Pompeo de Mattos	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	RS	57	https://www.camara.leg.br/internet/deputado/bandep/73486.jpg	dep.pompeodemattos@camara.leg.br
580	160601	https://dadosabertos.camara.leg.br/api/v2/deputados/160601	Pr. Marco Feliciano	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/160601.jpg	dep.pr.marcofeliciano@camara.leg.br
581	226075	https://dadosabertos.camara.leg.br/api/v2/deputados/226075	Priscila Costa	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	CE	57	https://www.camara.leg.br/internet/deputado/bandep/226075.jpg	\N
552	141518	https://dadosabertos.camara.leg.br/api/v2/deputados/141518	Paulinho da Força	SOLIDARIEDADE	https://dadosabertos.camara.leg.br/api/v2/partidos/37904	SP	57	https://www.camara.leg.br/internet/deputado/bandep/141518.jpg	dep.paulinhodaforca@camara.leg.br
553	220627	https://dadosabertos.camara.leg.br/api/v2/deputados/220627	Paulinho Freire	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RN	57	https://www.camara.leg.br/internet/deputado/bandep/220627.jpg	\N
589	233594	https://dadosabertos.camara.leg.br/api/v2/deputados/233594	Rafael Fera o Fiscal do Povo	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	RO	57	https://www.camara.leg.br/internet/deputado/bandep/233594.jpg	dep.rafaelfera@camara.leg.br
608	204362	https://dadosabertos.camara.leg.br/api/v2/deputados/204362	Ricardo Guidi	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SC	57	https://www.camara.leg.br/internet/deputado/bandep/204362.jpg	dep.ricardoguidi@camara.leg.br
611	220633	https://dadosabertos.camara.leg.br/api/v2/deputados/220633	Ricardo Salles	NOVO	https://dadosabertos.camara.leg.br/api/v2/partidos/37901	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220633.jpg	dep.ricardosalles@camara.leg.br
584	204390	https://dadosabertos.camara.leg.br/api/v2/deputados/204390	Professor Alcides	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	GO	57	https://www.camara.leg.br/internet/deputado/bandep/204390.jpg	dep.professoralcides@camara.leg.br
585	220580	https://dadosabertos.camara.leg.br/api/v2/deputados/220580	Professora Goreth	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	AP	57	https://www.camara.leg.br/internet/deputado/bandep/220580.jpg	\N
586	221338	https://dadosabertos.camara.leg.br/api/v2/deputados/221338	Professora Luciene Cavalcante	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	SP	57	https://www.camara.leg.br/internet/deputado/bandep/221338.jpg	dep.professoralucienecavalcante@camara.leg.br
587	160641	https://dadosabertos.camara.leg.br/api/v2/deputados/160641	Professora Marcivania	PCdoB	https://dadosabertos.camara.leg.br/api/v2/partidos/36779	AP	57	https://www.camara.leg.br/internet/deputado/bandep/160641.jpg	dep.professoramarcivania@camara.leg.br
588	220586	https://dadosabertos.camara.leg.br/api/v2/deputados/220586	Rafael Brito	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	AL	57	https://www.camara.leg.br/internet/deputado/bandep/220586.jpg	dep.rafaelbrito@camara.leg.br
591	220532	https://dadosabertos.camara.leg.br/api/v2/deputados/220532	Rafael Prudente	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	DF	57	https://www.camara.leg.br/internet/deputado/bandep/220532.jpg	dep.rafaelprudente@camara.leg.br
592	220626	https://dadosabertos.camara.leg.br/api/v2/deputados/220626	Rafael Simoes	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	MG	57	https://www.camara.leg.br/internet/deputado/bandep/220626.jpg	dep.rafaelsimoes@camara.leg.br
593	204567	https://dadosabertos.camara.leg.br/api/v2/deputados/204567	Raimundo Costa	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	BA	57	https://www.camara.leg.br/internet/deputado/bandep/204567.jpg	dep.raimundocosta@camara.leg.br
594	74084	https://dadosabertos.camara.leg.br/api/v2/deputados/74084	Raimundo Santos	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PA	57	https://www.camara.leg.br/internet/deputado/bandep/74084.jpg	dep.raimundosantos@camara.leg.br
595	115200	https://dadosabertos.camara.leg.br/api/v2/deputados/115200	Raniery Paulino	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	PB	57	https://www.camara.leg.br/internet/deputado/bandep/115200.jpg	\N
596	74161	https://dadosabertos.camara.leg.br/api/v2/deputados/74161	Reginaldo Lopes	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MG	57	https://www.camara.leg.br/internet/deputado/bandep/74161.jpg	dep.reginaldolopes@camara.leg.br
597	221378	https://dadosabertos.camara.leg.br/api/v2/deputados/221378	Reginete Bispo	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RS	57	https://www.camara.leg.br/internet/deputado/bandep/221378.jpg	\N
598	220606	https://dadosabertos.camara.leg.br/api/v2/deputados/220606	Reimont	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220606.jpg	dep.reimont@camara.leg.br
599	205865	https://dadosabertos.camara.leg.br/api/v2/deputados/205865	Reinhold Stephanes	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PR	57	https://www.camara.leg.br/internet/deputado/bandep/205865.jpg	dep.reinholdstephanes@camara.leg.br
600	225386	https://dadosabertos.camara.leg.br/api/v2/deputados/225386	Renan Ferreirinha	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/225386.jpg	\N
601	178989	https://dadosabertos.camara.leg.br/api/v2/deputados/178989	Renata Abreu	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	SP	57	https://www.camara.leg.br/internet/deputado/bandep/178989.jpg	dep.renataabreu@camara.leg.br
602	153423	https://dadosabertos.camara.leg.br/api/v2/deputados/153423	Renilce Nicodemos	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PA	57	https://www.camara.leg.br/internet/deputado/bandep/153423.jpg	dep.renilcenicodemos@camara.leg.br
603	73801	https://dadosabertos.camara.leg.br/api/v2/deputados/73801	Renildo Calheiros	PCdoB	https://dadosabertos.camara.leg.br/api/v2/partidos/36779	PE	57	https://www.camara.leg.br/internet/deputado/bandep/73801.jpg	dep.renildocalheiros@camara.leg.br
604	175765	https://dadosabertos.camara.leg.br/api/v2/deputados/175765	Ribamar Silva	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SP	57	https://www.camara.leg.br/internet/deputado/bandep/175765.jpg	dep.ribamarsilva@camara.leg.br
605	221329	https://dadosabertos.camara.leg.br/api/v2/deputados/221329	Ricardo Abrão	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/221329.jpg	dep.ricardoabrao@camara.leg.br
606	220543	https://dadosabertos.camara.leg.br/api/v2/deputados/220543	Ricardo Ayres	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	TO	57	https://www.camara.leg.br/internet/deputado/bandep/220543.jpg	dep.ricardoayres@camara.leg.br
607	73788	https://dadosabertos.camara.leg.br/api/v2/deputados/73788	Ricardo Barros	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PR	57	https://www.camara.leg.br/internet/deputado/bandep/73788.jpg	dep.ricardobarros@camara.leg.br
610	220694	https://dadosabertos.camara.leg.br/api/v2/deputados/220694	Ricardo Maia	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	BA	57	https://www.camara.leg.br/internet/deputado/bandep/220694.jpg	dep.ricardomaia@camara.leg.br
582	89536	https://dadosabertos.camara.leg.br/api/v2/deputados/89536	Prof. Paulo Fernando	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	DF	57	https://www.camara.leg.br/internet/deputado/bandep/89536.jpg	\N
583	220533	https://dadosabertos.camara.leg.br/api/v2/deputados/220533	Prof. Reginaldo Veras	PV	https://dadosabertos.camara.leg.br/api/v2/partidos/36851	DF	57	https://www.camara.leg.br/internet/deputado/bandep/220533.jpg	dep.prof.reginaldoveras@camara.leg.br
617	220613	https://dadosabertos.camara.leg.br/api/v2/deputados/220613	Roberto Monteiro Pai	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220613.jpg	dep.robertomonteiropai@camara.leg.br
619	220624	https://dadosabertos.camara.leg.br/api/v2/deputados/220624	Robinson Faria	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	RN	57	https://www.camara.leg.br/internet/deputado/bandep/220624.jpg	dep.robinsonfaria@camara.leg.br
630	160629	https://dadosabertos.camara.leg.br/api/v2/deputados/160629	Romero Rodrigues	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	PB	57	https://www.camara.leg.br/internet/deputado/bandep/160629.jpg	dep.romerorodrigues@camara.leg.br
641	160635	https://dadosabertos.camara.leg.br/api/v2/deputados/160635	Ruy Carneiro	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	PB	57	https://www.camara.leg.br/internet/deputado/bandep/160635.jpg	dep.ruycarneiro@camara.leg.br
644	233598	https://dadosabertos.camara.leg.br/api/v2/deputados/233598	Samuel Santos	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	GO	57	https://www.camara.leg.br/internet/deputado/bandep/233598.jpg	dep.samuelsantos@camara.leg.br
615	220693	https://dadosabertos.camara.leg.br/api/v2/deputados/220693	Roberta Roma	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	BA	57	https://www.camara.leg.br/internet/deputado/bandep/220693.jpg	dep.robertaroma@camara.leg.br
616	220588	https://dadosabertos.camara.leg.br/api/v2/deputados/220588	Roberto Duarte	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	AC	57	https://www.camara.leg.br/internet/deputado/bandep/220588.jpg	dep.robertoduarte@camara.leg.br
621	220546	https://dadosabertos.camara.leg.br/api/v2/deputados/220546	Rodolfo Nogueira	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MS	57	https://www.camara.leg.br/internet/deputado/bandep/220546.jpg	dep.rodolfonogueira@camara.leg.br
622	230767	https://dadosabertos.camara.leg.br/api/v2/deputados/230767	Rodrigo da Zaeli	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MT	57	https://www.camara.leg.br/internet/deputado/bandep/230767.jpg	dep.rodrigodazaeli@camara.leg.br
623	141531	https://dadosabertos.camara.leg.br/api/v2/deputados/141531	Rodrigo de Castro	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	MG	57	https://www.camara.leg.br/internet/deputado/bandep/141531.jpg	dep.rodrigodecastro@camara.leg.br
624	223128	https://dadosabertos.camara.leg.br/api/v2/deputados/223128	Rodrigo Estacho	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PR	57	https://www.camara.leg.br/internet/deputado/bandep/223128.jpg	dep.rodrigoestacho@camara.leg.br
625	220641	https://dadosabertos.camara.leg.br/api/v2/deputados/220641	Rodrigo Gambale	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220641.jpg	dep.rodrigogambale@camara.leg.br
626	141533	https://dadosabertos.camara.leg.br/api/v2/deputados/141533	Rodrigo Rollemberg	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	DF	57	https://www.camara.leg.br/internet/deputado/bandep/141533.jpg	dep.rodrigorollemberg@camara.leg.br
627	165470	https://dadosabertos.camara.leg.br/api/v2/deputados/165470	Rodrigo Valadares	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SE	57	https://www.camara.leg.br/internet/deputado/bandep/165470.jpg	dep.rodrigovaladares@camara.leg.br
628	220695	https://dadosabertos.camara.leg.br/api/v2/deputados/220695	Rogéria Santos	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	BA	57	https://www.camara.leg.br/internet/deputado/bandep/220695.jpg	dep.rogeriasantos@camara.leg.br
629	204480	https://dadosabertos.camara.leg.br/api/v2/deputados/204480	Rogério Correia	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204480.jpg	dep.rogeriocorreia@camara.leg.br
632	163321	https://dadosabertos.camara.leg.br/api/v2/deputados/163321	Ronaldo Nogueira	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RS	57	https://www.camara.leg.br/internet/deputado/bandep/163321.jpg	dep.ronaldonogueira@camara.leg.br
633	204525	https://dadosabertos.camara.leg.br/api/v2/deputados/204525	Rosana Valle	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204525.jpg	dep.rosanavalle@camara.leg.br
634	178945	https://dadosabertos.camara.leg.br/api/v2/deputados/178945	Rosangela Gomes	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/178945.jpg	\N
635	220644	https://dadosabertos.camara.leg.br/api/v2/deputados/220644	Rosangela Moro	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220644.jpg	dep.rosangelamoro@camara.leg.br
636	220620	https://dadosabertos.camara.leg.br/api/v2/deputados/220620	Rosângela Reis	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/220620.jpg	dep.rosangelareis@camara.leg.br
637	73806	https://dadosabertos.camara.leg.br/api/v2/deputados/73806	Roseana Sarney	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	MA	57	https://www.camara.leg.br/internet/deputado/bandep/73806.jpg	\N
638	74371	https://dadosabertos.camara.leg.br/api/v2/deputados/74371	Rubens Otoni	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	GO	57	https://www.camara.leg.br/internet/deputado/bandep/74371.jpg	dep.rubensotoni@camara.leg.br
639	178887	https://dadosabertos.camara.leg.br/api/v2/deputados/178887	Rubens Pereira Júnior	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MA	57	https://www.camara.leg.br/internet/deputado/bandep/178887.jpg	dep.rubenspereirajunior@camara.leg.br
640	73604	https://dadosabertos.camara.leg.br/api/v2/deputados/73604	Rui Falcão	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/73604.jpg	dep.ruifalcao@camara.leg.br
643	204535	https://dadosabertos.camara.leg.br/api/v2/deputados/204535	Sâmia Bomfim	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204535.jpg	dep.samiabomfim@camara.leg.br
613	213274	https://dadosabertos.camara.leg.br/api/v2/deputados/213274	Ricardo Silva	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SP	57	https://www.camara.leg.br/internet/deputado/bandep/213274.jpg	\N
614	204489	https://dadosabertos.camara.leg.br/api/v2/deputados/204489	Robério Monteiro	PDT	https://dadosabertos.camara.leg.br/api/v2/partidos/36786	CE	57	https://www.camara.leg.br/internet/deputado/bandep/204489.jpg	dep.roberiomonteiro@camara.leg.br
648	220631	https://dadosabertos.camara.leg.br/api/v2/deputados/220631	Samuel Viana	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	MG	57	https://www.camara.leg.br/internet/deputado/bandep/220631.jpg	dep.samuelviana@camara.leg.br
661	204360	https://dadosabertos.camara.leg.br/api/v2/deputados/204360	Silvia Cristina	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	RO	57	https://www.camara.leg.br/internet/deputado/bandep/204360.jpg	dep.silviacristina@camara.leg.br
652	204387	https://dadosabertos.camara.leg.br/api/v2/deputados/204387	Sargento Fahur	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PR	57	https://www.camara.leg.br/internet/deputado/bandep/204387.jpg	dep.sargentofahur@camara.leg.br
653	220621	https://dadosabertos.camara.leg.br/api/v2/deputados/220621	Sargento Gonçalves	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RN	57	https://www.camara.leg.br/internet/deputado/bandep/220621.jpg	dep.sargentogoncalves@camara.leg.br
654	220618	https://dadosabertos.camara.leg.br/api/v2/deputados/220618	Sargento Portugal	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220618.jpg	dep.sargentoportugal@camara.leg.br
655	220713	https://dadosabertos.camara.leg.br/api/v2/deputados/220713	Saullo Vianna	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	AM	57	https://www.camara.leg.br/internet/deputado/bandep/220713.jpg	\N
656	226837	https://dadosabertos.camara.leg.br/api/v2/deputados/226837	Saulo Pedroso	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	SP	57	https://www.camara.leg.br/internet/deputado/bandep/226837.jpg	dep.saulopedroso@camara.leg.br
657	73808	https://dadosabertos.camara.leg.br/api/v2/deputados/73808	Sérgio Brito	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	BA	57	https://www.camara.leg.br/internet/deputado/bandep/73808.jpg	\N
658	178933	https://dadosabertos.camara.leg.br/api/v2/deputados/178933	Sergio Souza	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	PR	57	https://www.camara.leg.br/internet/deputado/bandep/178933.jpg	dep.sergiosouza@camara.leg.br
659	204557	https://dadosabertos.camara.leg.br/api/v2/deputados/204557	Sidney Leite	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	AM	57	https://www.camara.leg.br/internet/deputado/bandep/204557.jpg	dep.sidneyleite@camara.leg.br
660	74356	https://dadosabertos.camara.leg.br/api/v2/deputados/74356	Silas Câmara	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	AM	57	https://www.camara.leg.br/internet/deputado/bandep/74356.jpg	dep.silascamara@camara.leg.br
663	220579	https://dadosabertos.camara.leg.br/api/v2/deputados/220579	Silvia Waiãpi	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	AP	57	https://www.camara.leg.br/internet/deputado/bandep/220579.jpg	\N
664	227310	https://dadosabertos.camara.leg.br/api/v2/deputados/227310	Silvio Antonio	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MA	57	https://www.camara.leg.br/internet/deputado/bandep/227310.jpg	\N
665	204425	https://dadosabertos.camara.leg.br/api/v2/deputados/204425	Silvio Costa Filho	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	PE	57	https://www.camara.leg.br/internet/deputado/bandep/204425.jpg	\N
666	220569	https://dadosabertos.camara.leg.br/api/v2/deputados/220569	Silvye Alves	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	GO	57	https://www.camara.leg.br/internet/deputado/bandep/220569.jpg	dep.silvyealves@camara.leg.br
667	220651	https://dadosabertos.camara.leg.br/api/v2/deputados/220651	Simone Marquetto	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220651.jpg	dep.simonemarquetto@camara.leg.br
668	104552	https://dadosabertos.camara.leg.br/api/v2/deputados/104552	Socorro Neri	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	AC	57	https://www.camara.leg.br/internet/deputado/bandep/104552.jpg	dep.socorroneri@camara.leg.br
669	220643	https://dadosabertos.camara.leg.br/api/v2/deputados/220643	Sônia Guajajara	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	SP	57	https://www.camara.leg.br/internet/deputado/bandep/220643.jpg	\N
670	220575	https://dadosabertos.camara.leg.br/api/v2/deputados/220575	Sonize Barbosa	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	AP	57	https://www.camara.leg.br/internet/deputado/bandep/220575.jpg	\N
671	178946	https://dadosabertos.camara.leg.br/api/v2/deputados/178946	Soraya Santos	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/178946.jpg	dep.sorayasantos@camara.leg.br
672	178947	https://dadosabertos.camara.leg.br/api/v2/deputados/178947	Sóstenes Cavalcante	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/178947.jpg	dep.sostenescavalcante@camara.leg.br
673	92776	https://dadosabertos.camara.leg.br/api/v2/deputados/92776	Stefano Aguiar	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	MG	57	https://www.camara.leg.br/internet/deputado/bandep/92776.jpg	dep.stefanoaguiar@camara.leg.br
674	204534	https://dadosabertos.camara.leg.br/api/v2/deputados/204534	Tabata Amaral	PSB	https://dadosabertos.camara.leg.br/api/v2/partidos/36832	SP	57	https://www.camara.leg.br/internet/deputado/bandep/204534.jpg	dep.tabataamaral@camara.leg.br
675	230177	https://dadosabertos.camara.leg.br/api/v2/deputados/230177	Tadeu Oliveira	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	CE	57	https://www.camara.leg.br/internet/deputado/bandep/230177.jpg	\N
676	220682	https://dadosabertos.camara.leg.br/api/v2/deputados/220682	Tadeu Veneri	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PR	57	https://www.camara.leg.br/internet/deputado/bandep/220682.jpg	dep.tadeuveneri@camara.leg.br
677	204464	https://dadosabertos.camara.leg.br/api/v2/deputados/204464	Talíria Petrone	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/204464.jpg	dep.taliriapetrone@camara.leg.br
650	204416	https://dadosabertos.camara.leg.br/api/v2/deputados/204416	Sanderson	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RS	57	https://www.camara.leg.br/internet/deputado/bandep/204416.jpg	dep.sanderson@camara.leg.br
651	160621	https://dadosabertos.camara.leg.br/api/v2/deputados/160621	Sandro Alex	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	PR	57	https://www.camara.leg.br/internet/deputado/bandep/160621.jpg	\N
685	220684	https://dadosabertos.camara.leg.br/api/v2/deputados/220684	Tião Medeiros	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PR	57	https://www.camara.leg.br/internet/deputado/bandep/220684.jpg	dep.tiaomedeiros@camara.leg.br
687	178934	https://dadosabertos.camara.leg.br/api/v2/deputados/178934	Toninho Wandscheer	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PR	57	https://www.camara.leg.br/internet/deputado/bandep/178934.jpg	dep.toninhowandscheer@camara.leg.br
693	204396	https://dadosabertos.camara.leg.br/api/v2/deputados/204396	Vermelho	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	PR	57	https://www.camara.leg.br/internet/deputado/bandep/204396.jpg	dep.vermelho@camara.leg.br
700	91228	https://dadosabertos.camara.leg.br/api/v2/deputados/91228	Waldemar Oliveira	AVANTE	https://dadosabertos.camara.leg.br/api/v2/partidos/36898	PE	57	https://www.camara.leg.br/internet/deputado/bandep/91228.jpg	dep.waldemaroliveira@camara.leg.br
686	160976	https://dadosabertos.camara.leg.br/api/v2/deputados/160976	Tiririca	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SP	57	https://www.camara.leg.br/internet/deputado/bandep/160976.jpg	dep.tiririca@camara.leg.br
691	160610	https://dadosabertos.camara.leg.br/api/v2/deputados/160610	Valmir Assunção	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	BA	57	https://www.camara.leg.br/internet/deputado/bandep/160610.jpg	dep.valmirassuncao@camara.leg.br
682	220597	https://dadosabertos.camara.leg.br/api/v2/deputados/220597	Thiago Flores	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	RO	57	https://www.camara.leg.br/internet/deputado/bandep/220597.jpg	dep.thiagoflores@camara.leg.br
692	74376	https://dadosabertos.camara.leg.br/api/v2/deputados/74376	Vander Loubet	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	MS	57	https://www.camara.leg.br/internet/deputado/bandep/74376.jpg	dep.vanderloubet@camara.leg.br
697	141555	https://dadosabertos.camara.leg.br/api/v2/deputados/141555	Vinicius Carvalho	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	SP	57	https://www.camara.leg.br/internet/deputado/bandep/141555.jpg	dep.viniciuscarvalho@camara.leg.br
698	160591	https://dadosabertos.camara.leg.br/api/v2/deputados/160591	Vinicius Gurgel	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	AP	57	https://www.camara.leg.br/internet/deputado/bandep/160591.jpg	dep.viniciusgurgel@camara.leg.br
695	74283	https://dadosabertos.camara.leg.br/api/v2/deputados/74283	Vicentinho	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	SP	57	https://www.camara.leg.br/internet/deputado/bandep/74283.jpg	dep.vicentinho@camara.leg.br
696	137070	https://dadosabertos.camara.leg.br/api/v2/deputados/137070	Vicentinho Júnior	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	TO	57	https://www.camara.leg.br/internet/deputado/bandep/137070.jpg	dep.vicentinhojunior@camara.leg.br
699	178992	https://dadosabertos.camara.leg.br/api/v2/deputados/178992	Vitor Lippi	PSDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36835	SP	57	https://www.camara.leg.br/internet/deputado/bandep/178992.jpg	dep.vitorlippi@camara.leg.br
701	160569	https://dadosabertos.camara.leg.br/api/v2/deputados/160569	Waldenor Pereira	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	BA	57	https://www.camara.leg.br/internet/deputado/bandep/160569.jpg	dep.waldenorpereira@camara.leg.br
702	220601	https://dadosabertos.camara.leg.br/api/v2/deputados/220601	Washington Quaquá	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220601.jpg	\N
706	224333	https://dadosabertos.camara.leg.br/api/v2/deputados/224333	Welter	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PR	57	https://www.camara.leg.br/internet/deputado/bandep/224333.jpg	dep.welter@camara.leg.br
703	160518	https://dadosabertos.camara.leg.br/api/v2/deputados/160518	Weliton Prado	SOLIDARIEDADE	https://dadosabertos.camara.leg.br/api/v2/partidos/37904	MG	57	https://www.camara.leg.br/internet/deputado/bandep/160518.jpg	dep.welitonprado@camara.leg.br
705	74043	https://dadosabertos.camara.leg.br/api/v2/deputados/74043	Wellington Roberto	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	PB	57	https://www.camara.leg.br/internet/deputado/bandep/74043.jpg	dep.wellingtonroberto@camara.leg.br
684	143084	https://dadosabertos.camara.leg.br/api/v2/deputados/143084	Tiago Dimas	PODE	https://dadosabertos.camara.leg.br/api/v2/partidos/36896	TO	57	https://www.camara.leg.br/internet/deputado/bandep/143084.jpg	dep.tiagodimas@camara.leg.br
679	220552	https://dadosabertos.camara.leg.br/api/v2/deputados/220552	Zucco	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	RS	57	https://www.camara.leg.br/internet/deputado/bandep/220552.jpg	dep.zucco@camara.leg.br
678	220598	https://dadosabertos.camara.leg.br/api/v2/deputados/220598	Tarcísio Motta	PSOL	https://dadosabertos.camara.leg.br/api/v2/partidos/36839	RJ	57	https://www.camara.leg.br/internet/deputado/bandep/220598.jpg	dep.tarcisiomotta@camara.leg.br
689	157130	https://dadosabertos.camara.leg.br/api/v2/deputados/157130	Túlio Gadêlha	REDE	https://dadosabertos.camara.leg.br/api/v2/partidos/36886	PE	57	https://www.camara.leg.br/internet/deputado/bandep/157130.jpg	dep.tuliogadelha@camara.leg.br
681	220560	https://dadosabertos.camara.leg.br/api/v2/deputados/220560	Thiago de Joaldo	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	SE	57	https://www.camara.leg.br/internet/deputado/bandep/220560.jpg	dep.thiagodejoaldo@camara.leg.br
690	223398	https://dadosabertos.camara.leg.br/api/v2/deputados/223398	Ulisses Guimarães	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	MG	57	https://www.camara.leg.br/internet/deputado/bandep/223398.jpg	\N
707	74044	https://dadosabertos.camara.leg.br/api/v2/deputados/74044	Wilson Santiago	REPUBLICANOS	https://dadosabertos.camara.leg.br/api/v2/partidos/37908	PB	57	https://www.camara.leg.br/internet/deputado/bandep/74044.jpg	dep.wilsonsantiago@camara.leg.br
708	182146	https://dadosabertos.camara.leg.br/api/v2/deputados/182146	Wolmer Araújo	SOLIDARIEDADE	https://dadosabertos.camara.leg.br/api/v2/partidos/37904	MA	57	https://www.camara.leg.br/internet/deputado/bandep/182146.jpg	\N
710	220564	https://dadosabertos.camara.leg.br/api/v2/deputados/220564	Yandra Moura	UNIÃO	https://dadosabertos.camara.leg.br/api/v2/partidos/38009	SE	57	https://www.camara.leg.br/internet/deputado/bandep/220564.jpg	dep.yandramoura@camara.leg.br
711	220660	https://dadosabertos.camara.leg.br/api/v2/deputados/220660	Yury do Paredão	MDB	https://dadosabertos.camara.leg.br/api/v2/partidos/36899	CE	57	https://www.camara.leg.br/internet/deputado/bandep/220660.jpg	dep.yurydoparedao@camara.leg.br
714	230768	https://dadosabertos.camara.leg.br/api/v2/deputados/230768	Zé Adriano	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	AC	57	https://www.camara.leg.br/internet/deputado/bandep/230768.jpg	dep.zeadriano@camara.leg.br
715	220536	https://dadosabertos.camara.leg.br/api/v2/deputados/220536	Zé Haroldo Cathedral	PSD	https://dadosabertos.camara.leg.br/api/v2/partidos/36834	RR	57	https://www.camara.leg.br/internet/deputado/bandep/220536.jpg	dep.zeharoldocathedral@camara.leg.br
716	204559	https://dadosabertos.camara.leg.br/api/v2/deputados/204559	Zé Neto	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	BA	57	https://www.camara.leg.br/internet/deputado/bandep/204559.jpg	dep.zeneto@camara.leg.br
717	160632	https://dadosabertos.camara.leg.br/api/v2/deputados/160632	Zé Silva	SOLIDARIEDADE	https://dadosabertos.camara.leg.br/api/v2/partidos/37904	MG	57	https://www.camara.leg.br/internet/deputado/bandep/160632.jpg	dep.zesilva@camara.leg.br
718	220558	https://dadosabertos.camara.leg.br/api/v2/deputados/220558	Zé Trovão	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	SC	57	https://www.camara.leg.br/internet/deputado/bandep/220558.jpg	dep.zetrovao@camara.leg.br
719	204517	https://dadosabertos.camara.leg.br/api/v2/deputados/204517	Zé Vitor	PL	https://dadosabertos.camara.leg.br/api/v2/partidos/37906	MG	57	https://www.camara.leg.br/internet/deputado/bandep/204517.jpg	dep.zevitor@camara.leg.br
720	160592	https://dadosabertos.camara.leg.br/api/v2/deputados/160592	Zeca Dirceu	PT	https://dadosabertos.camara.leg.br/api/v2/partidos/36844	PR	57	https://www.camara.leg.br/internet/deputado/bandep/160592.jpg	dep.zecadirceu@camara.leg.br
721	220592	https://dadosabertos.camara.leg.br/api/v2/deputados/220592	Zezinho Barbary	PP	https://dadosabertos.camara.leg.br/api/v2/partidos/37903	AC	57	https://www.camara.leg.br/internet/deputado/bandep/220592.jpg	dep.zezinhobarbary@camara.leg.br
\.


--
-- Data for Name: despesas; Type: TABLE DATA; Schema: public; Owner: ismael
--

COPY public.despesas (id_local, ano, mes, "tipoDespesa", "codDocumento", "tipoDocumento", "codTipoDocumento", "dataDocumento", "numDocumento", "valorDocumento", "urlDocumento", "nomeFornecedor", "cnpjCpfFornecedor", "valorLiquido", "valorGlosa", "numRessarcimento", "codLote", parcela, "deputadoId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: deputados_id_local_seq; Type: SEQUENCE SET; Schema: public; Owner: ismael
--

SELECT pg_catalog.setval('public.deputados_id_local_seq', 2799, true);


--
-- Name: despesas_id_local_seq; Type: SEQUENCE SET; Schema: public; Owner: ismael
--

SELECT pg_catalog.setval('public.despesas_id_local_seq', 803, true);


--
-- Name: despesas PK_27107fd4862a05c5e12b7cf1f8e; Type: CONSTRAINT; Schema: public; Owner: ismael
--

ALTER TABLE ONLY public.despesas
    ADD CONSTRAINT "PK_27107fd4862a05c5e12b7cf1f8e" PRIMARY KEY (id_local);


--
-- Name: deputados PK_39497907511fd6968a3eafaee20; Type: CONSTRAINT; Schema: public; Owner: ismael
--

ALTER TABLE ONLY public.deputados
    ADD CONSTRAINT "PK_39497907511fd6968a3eafaee20" PRIMARY KEY (id_local);


--
-- Name: deputados UQ_056cd31948832d35f87f891915e; Type: CONSTRAINT; Schema: public; Owner: ismael
--

ALTER TABLE ONLY public.deputados
    ADD CONSTRAINT "UQ_056cd31948832d35f87f891915e" UNIQUE (id);


--
-- Name: IDX_68291670543921f294c3b98602; Type: INDEX; Schema: public; Owner: ismael
--

CREATE INDEX "IDX_68291670543921f294c3b98602" ON public.despesas USING btree ("tipoDespesa");


--
-- Name: IDX_b3137f830bfedaa103d9835699; Type: INDEX; Schema: public; Owner: ismael
--

CREATE INDEX "IDX_b3137f830bfedaa103d9835699" ON public.despesas USING btree (ano, mes);


--
-- Name: IDX_b5209ed9c4be5ab5f82fea0a22; Type: INDEX; Schema: public; Owner: ismael
--

CREATE INDEX "IDX_b5209ed9c4be5ab5f82fea0a22" ON public.despesas USING btree ("deputadoId", ano, mes);


--
-- Name: despesas FK_8cdb7d41b3bf6a6f36c77ad1e30; Type: FK CONSTRAINT; Schema: public; Owner: ismael
--

ALTER TABLE ONLY public.despesas
    ADD CONSTRAINT "FK_8cdb7d41b3bf6a6f36c77ad1e30" FOREIGN KEY ("deputadoId") REFERENCES public.deputados(id);


--
-- PostgreSQL database dump complete
--

